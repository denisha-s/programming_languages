open Javascript_ast
open Javascript_env
open Javascript_main
open Util

(*
 * Check javascript_ast.ml and javascript_env.ml for the following useful functionality:
 * - str_float               -- convert a float to a string
 * - to_num, to_bool, to_str -- do the JavaScript automatic type conversion
 * - bind_environment        -- add a variable binding to the environment
 * - read_environment        -- look up a variable's value in the environment
 * - empty_env               -- the empty environment
 *)

(*
 * (eval env p) should reduce a program in initial environment env to a *value*
 * In general, if Node.js produces a *value* for an example JavaScript
 * program, your evaluator should produce that same value.
 * You should support basic JavaScript (recursive higher-order) functions
 * with lexical scoping.
 *
 * See the assignment README for more details.
 *)

(* evaluate a program *)
let rec eval (env : environment_t) (p: program_t) : value_t = match p with
  | ExprProgram(_,e) -> eval_expr env e
  | StmtProgram(_, s, p1) -> eval (eval_stmt env s) p1
  | _ -> raise (UnimplementedProgram(p))

(* evaluate a block *)
and eval_block (env:environment_t) (p:block_t) : value_t = match p with
  | ReturnBlock(_,e) -> eval_expr env e
  | StmtBlock(_, s, b) -> eval_block (eval_stmt env s) b
  | _ -> raise (UnimplementedBlock(p))

and eval_stmt (env: environment_t) (s: stmt_t) : environment_t = match s with
  | ConstStmt(_, i, e1) ->
    let new_val = eval_expr env e1 in
    bind_environment env i Immutable new_val
  | LetStmt(_, i, e1) ->
    let new_val = eval_expr env e1 in
    bind_environment env i Mutable new_val
  | _ -> raise (UnimplementedStmt(s))

(* evaluate a value *)
and eval_expr (env:environment_t) (e:expr_t) : value_t =
  (*Printf.printf "%s %s\n" (str_expr e) (str_environment_simple env);*)
  match e with
  | VarExpr(_, var) ->
    (try
       let (_, value) = StringMap.find var env in value
     with Not_found ->
       raise (UndeclaredVar(var)))
  | ValExpr(_, value) -> value
  | UopExpr(_, NegUop, e) -> NumVal(-. (to_num (eval_expr env e)))
  | UopExpr(_, NotUop, e) -> BoolVal(not (to_bool (eval_expr env e)))
  | BopExpr(_,e1,MinusBop,e2) ->
     NumVal(to_num (eval_expr env e1) -. to_num (eval_expr env e2))
  | BopExpr(_, e1, PlusBop, e2) ->
    (let v1 = eval_expr env e1 in
    let v2 = eval_expr env e2 in
    match (v1, v2) with
    | (StrVal(s1), StrVal(s2)) -> StrVal(s1 ^ to_str v2)
    | (_, _) -> NumVal(to_num (eval_expr env e1) +. to_num (eval_expr env e2)))
  | BopExpr(_,e1,TimesBop,e2) ->
      NumVal(to_num (eval_expr env e1) *. to_num (eval_expr env e2))
  | BopExpr(_,e1,DivBop,e2) ->
      NumVal(mod_float (to_num (eval_expr env e1)) (to_num (eval_expr env e2)))
  | BopExpr(_,e1,EqBop,e2) ->
      BoolVal(to_num (eval_expr env e1) = to_num (eval_expr env e2))
  | BopExpr(_,e1,NeqBop,e2) ->
      BoolVal(to_num (eval_expr env e1) <> to_num (eval_expr env e2))
  | BopExpr(_,e1,LtBop,e2) ->
      (let v1 = eval_expr env e1 in
      let v2 = eval_expr env e2 in
      match (v1, v2) with
      | (StrVal(s1), StrVal(s2)) -> BoolVal(s1 < s2)
      | (_, _) -> BoolVal(to_num v1 < to_num v2))
  | BopExpr(_, e1, LteBop, e2) ->
      (let v1 = eval_expr env e1 in
      let v2 = eval_expr env e2 in
      match (v1, v2) with
      | (StrVal(s1), StrVal(s2)) -> BoolVal(s1 <= s2)
      | (_, _) -> BoolVal(to_num v1 <= to_num v2))
  | BopExpr(_,e1,GtBop,e2) ->
      (let v1 = eval_expr env e1 in
      let v2 = eval_expr env e2 in
      match (v1, v2) with
      | (StrVal(s1), StrVal(s2)) -> BoolVal(s1 > s2)
      | (_, _) -> BoolVal(to_num v1 > to_num v2))
  | BopExpr(_,e1,GteBop,e2) ->
      (let v1 = eval_expr env e1 in
      let v2 = eval_expr env e2 in
      match (v1, v2) with
      | (StrVal(s1), StrVal(s2)) -> BoolVal(s1 >= s2)
      | (_, _) -> BoolVal(to_num v1 >= to_num v2))
  | BopExpr(_,e1,AndBop,e2) ->
      BoolVal(to_bool (eval_expr env e1) && to_bool (eval_expr env e2))
  | BopExpr(_, e1, OrBop, e2) ->
      (let v1 = eval_expr env e1 in
      if to_bool v1 then v1 else eval_expr env e2)
  | FuncExpr(_, lambda) ->
      (let (name, args, body, ret_type) = lambda in
      ClosureVal(env, lambda))
  | IfExpr(_, cond, e_true, e_false) ->
    if to_bool (eval_expr env cond) then eval_expr env e_true else eval_expr env e_false
  (* function call evaluation *)
  | CallExpr(_, func_expr, args) ->
    (let func_val = eval_expr env func_expr in
    match func_val with
    | ClosureVal(closure_env, (name, params, body, _)) ->
      if List.length params = List.length args then
        let arg_values = List.map (eval_expr env) args in
        let arg_bindings = List.combine (List.map fst params) arg_values in
        let new_env = List.fold_left (fun acc_env (param, value) -> bind_environment acc_env param Immutable value) closure_env arg_bindings in
        let recursive_env = (match name with
          | Some n -> bind_environment new_env n Immutable func_val
          | None -> new_env) in
        eval_block recursive_env body
      else
        raise (InvalidCall(e))
    | _ -> raise (InvalidCall(e)))
  | PrintExpr(_, e) ->
    let value = eval_expr env e in
    Printf.printf "%s\n" (to_str value);
    UndefVal
  | _ -> raise (UnimplementedExpr(e))

(*********)
(* Tests *)
(*********)

let test_group name tests =
  (name, compose (eval empty_env) parse_string, eq_value, eq_exn,
   Some((fun (x : string) -> x),str_value),
   (* None, *)
   tests)

(* basic tests for the evaluator (do not modify) *)
let simple_expr_eval_tests =
  test_group "Simple Expression Evaluation"
    [
      (None, "1 + true",                     Ok(NumVal(2.0)));
      (None, "false + true",                 Ok(NumVal(1.0)));
      (None, "100 || 200",                   Ok(NumVal(100.0)));
      (None, "-false",                       Ok(NumVal(0.0)));
      (None, "1 + 1",                        Ok(NumVal(2.0)));
      (None, "3 + (4 + 5)",                  Ok(NumVal(12.0)));
      (None, "3 * (4 + 5)",                  Ok(NumVal(27.0)));
      (None, "-6 * 90 - 8",                  Ok(NumVal(-548.0)));
      (None, "-100 + 50",                    Ok(NumVal(-50.0)));
      (None, "true && (false || true)",      Ok(BoolVal(true)));
      (None, "true && (false || !true)",     Ok(BoolVal(false)));
      (None, "1 < 2",                        Ok(BoolVal(true)));
      (None, "100 === 100",                  Ok(BoolVal(true)));
      (None, "100 === 101",                  Ok(BoolVal(false)));
      (None, "100 !== 200",                  Ok(BoolVal(true)));
      (None, "true === true",                Ok(BoolVal(true)));
      (None, "0 / 0",                        Ok(NumVal(nan)));
      (None, "console.log(\"Hello World\")", Ok(UndefVal));
      (None, "(1 < 2) ? 123 : 124",          Ok(NumVal(123.0)));
      (None, "\"aaa\" < \"aaaa\"",           Ok(BoolVal(true)));
      (None, "\"bbb\" < \"aaa\"",            Ok(BoolVal(false)));
      (None, "\"hello\"+\" \"+\"world\"",    Ok(StrVal("hello world")));
    ]

let simple_var_eval_tests =
  test_group "Simple Variable Evaluation"
    [
      (None, "const x = 1; x+1",            Ok(NumVal(2.0)));
      (None, "const x=1; const y=2; x+y",   Ok(NumVal(3.0)));
      (None, "const x=3; const y=x*2+1; y", Ok(NumVal(7.0)));
      (None, "const x = 1; y",              Error(UndeclaredVar("y")));
    ]


let var_eval_tests =
  test_group "Variable Evaluation"
    [
      (None, "const x=5; x+y",            Error(UndeclaredVar("y")));
      (None, "const z=10; const y=5; const z = y*3+4; z",   Ok(NumVal(19.0)));
      (None, "const x=3; const y=x+3; x*3", Ok(NumVal(9.0)));
    ]


let fact_js = "function factorial(n){return (n <= 1) ? 1 : (n * factorial(n-1));}"
let fib_js = "function fib(x){return x<=0 ? 0 : (x===1 ? 1 : fib(x-1)+fib(x-2));}"
let scopes_js =
"(function (x) {
    return function(f) {
        return function (x) {
            return f(0);
        }(2);
    } (function (y) {return x;});
} (1))"

let readme1_js =
  "const f = function(x){ return x+1; };
   const r = f(2);
   r+3"

let readme2_js =
  "const x = 5;
   const f = function(y){ return x + y; };
   (function(z) { const x = 7; return f(6); })(0)"

(* basic tests for the evaluator (do not modify) *)
let simple_func_eval_tests =
  test_group "Simple Function Definition Evaluation"
    [
      (None, "function test(x){const x = 123; return x;}",
       Ok(ClosureVal(StringMap.empty,(
                Some("test"),
                [("x",None)],
                StmtBlock(NoPos,
                          ConstStmt(NoPos,
                                    "x",
                                    ValExpr(NoPos,NumVal(123.0))),
                          ReturnBlock(NoPos,VarExpr(NoPos,"x"))),
                None))));
      (None, fact_js,
       Ok(ClosureVal(StringMap.empty,(
                Some("factorial"),
                [("n",None)],
                ReturnBlock(NoPos,IfExpr(NoPos,
                                         BopExpr(NoPos,VarExpr(NoPos,"n"),LteBop,ValExpr(NoPos,NumVal(1.0))),
                                         ValExpr(NoPos,NumVal(1.0)),
                                         BopExpr(NoPos,VarExpr(NoPos,"n"),TimesBop,CallExpr(NoPos,VarExpr(NoPos,"factorial"),[BopExpr(NoPos,VarExpr(NoPos,"n"),MinusBop,ValExpr(NoPos,NumVal(1.0)))]))
                  )),
                None))));

    ]
(* note - you can use the following to print a program for debugging *)
(* let _ = Printf.printf "RESULT = %s\n" (str_program (parse_string "const x = 1 + 1; x * 2")) *)

let func_eval_tests =
  test_group "Function Definition Evaluation"
    [
      (None, "function f(x) {return x+3;}",
       Ok(ClosureVal(StringMap.empty,
                (Some("f"),
                 [("x", None)],
                 ReturnBlock(NoPos,
                             BopExpr(NoPos, VarExpr(NoPos, "x"), PlusBop, ValExpr(NoPos, NumVal(3.0)))),
                 None))));
      (None, "function f(x) {const y=2; return x+y;}",
       Ok(ClosureVal(StringMap.empty,
                    (Some("f"),
                    [("x", None)],
                    StmtBlock(NoPos,
                          ConstStmt(NoPos,
                                    "y",
                                    ValExpr(NoPos,NumVal(2.0))),
                          ReturnBlock(NoPos,BopExpr(NoPos, VarExpr(NoPos, "x"), PlusBop, VarExpr(NoPos, "y")))),
                    None))));
    ]


let simple_call_eval_tests =
  test_group "Simple Call Evaluation"
    [
      (None, "const f = function(x){return x+1;}; f(1)",                    Ok(NumVal(2.0)));
      (None, "const y = 5; const f = function(x){return x+1;}; f(y)",       Ok(NumVal(6.0)));
      (Some("recursion"), "const f = function t(x){return x===0 ? 0 : x+t(x-1);}; f(5)", Ok(NumVal(15.0)));

      (Some("Readme 1"), readme1_js, Ok(NumVal(6.0)));
      (Some("Readme 2"), readme2_js, Ok(NumVal(11.0)));
      (Some("Lecture Scoping Test"), scopes_js, Ok(NumVal(1.0)))
    ]

let call_eval_tests =
  test_group "Call Evaluation"
    [
      (Some("fib"), Printf.sprintf "(%s)(30)" fib_js, Ok(NumVal(832040.0)));
      (Some("fact"), Printf.sprintf "(%s)(10)" fact_js, Ok(NumVal(3628800.0)));
      (Some("return arg"), "const identity = function(x) { return x; }; identity(777)", Ok(NumVal(777.0)));
      (Some("factorial"), Printf.sprintf "(%s)(7)" fact_js, Ok(NumVal(5040.0)));
      (Some("func call"), "const f = function(x){return x*3;}; f(1)", Ok(NumVal(3.0)));
      (Some("nested fact"), Printf.sprintf "(%s)(%s(3))" fact_js fact_js, Ok(NumVal(720.0)));
    ]

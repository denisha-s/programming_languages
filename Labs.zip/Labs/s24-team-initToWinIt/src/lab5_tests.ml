open Javascript_parser;;
open Javascript_lexer;;
open Javascript_main;;
open Javascript_ast;;
open Util;;

let lexer_test_fun s =
  tokenize (Lexing.from_string s)


let lexer_tests =
  ("lexer_tests",
   lexer_test_fun,
   (=), (=),
   Some((fun (x : string) -> x), str_token_list),
   [
     (Some("simple js"),
      "1 + 2",
      Ok([NUMBER(1.0); ADD_OP; NUMBER(2.0); EOF]));
     (Some("binary"),
     "0b101 + 0B0010",
     Ok([NUMBER(5.0); ADD_OP; NUMBER(2.0); EOF]));
     (Some("octal"),
      "0o10 - 0O100",
      Ok([NUMBER(8.0); SUB_OP; NUMBER(64.0); EOF]));
     (Some("hex"),
      "0xfd / 0X5e",
      Ok([NUMBER(253.0); DIV_OP; NUMBER(94.0); EOF]));
     (Some("floating point"),
      "16.0 * 12.5",
      Ok([NUMBER(16.0); MUL_OP; NUMBER(12.5); EOF]));
     (Some("sci not"),
      "12.345E2 + .12345e2",
      Ok([NUMBER(1234.5); ADD_OP; NUMBER(12.345); EOF]));
     (Some("ident and true"),
      "_trueIdent = TRUE",
      Ok([IDENT("_trueIdent"); ASSIGN_OP; TRUE_KW; EOF]));
     (Some("ident and false"),
      "false_Ident = false",
      Ok([IDENT("false_Ident"); ASSIGN_OP; FALSE_KW; EOF]));
      (Some("sci not2"),
      "12.345E2 + .12345e3",
      Ok([NUMBER(1234.5); ADD_OP; NUMBER(123.45); EOF]));
      (Some("sci not3"),
      "12.345E2 + 1.2345e-1",
      Ok([NUMBER(1234.5); ADD_OP; NUMBER(0.12345); EOF]));
      (Some("sci not4"),
      "12.345E2 + .12345e1",
      Ok([NUMBER(1234.5); ADD_OP; NUMBER(1.2345); EOF]));

   ])

let parser_tests =
  ("parser_tests",
   parse_string,
   eq_program, (=),
   Some((fun (x : string) -> x), str_program),
   [
      (Some("simple expression"),
        "1 + 2",
        Ok(ExprProgram(NoPos, BopExpr( NoPos,
                                       ValExpr(NoPos, NumVal(1.0)),
                                       PlusBop,
                                       ValExpr(NoPos, NumVal(2.0)) ))));

      (Some("Identity lambda"),
        "function (x) {return x;}",
        Ok(ExprProgram(NoPos,
                       FuncExpr(NoPos,
                                (None, (* ident_t option *)
                                 [("x", None)], (* typed_ident_t list *)
                                 ReturnBlock(NoPos, VarExpr(NoPos, "x")), (* block_t *)
                                 None (* typ_t option *)
                                )))));

      (Some("Simple expressions sub1"),
      "1 - 2",
      Ok(ExprProgram(NoPos, BopExpr( NoPos,
                                     ValExpr(NoPos, NumVal(1.0)),
                                     MinusBop,
                                     ValExpr(NoPos, NumVal(2.0)) ))));

      (Some("Unary minus"),
      "-1",
      Ok(ExprProgram(NoPos,
                            UopExpr(NoPos, NegUop,
                            ValExpr(NoPos, NumVal(1.0))))));

      (Some("Varied precedence w/ paren"),
      "(14 + 8) / 2",
      Ok (ExprProgram (NoPos,
                            BopExpr(NoPos,
                            BopExpr(NoPos,
                            ValExpr(NoPos, NumVal(14.0)),
                            PlusBop,
                            ValExpr(NoPos, NumVal(8.0))),
                            DivBop,
                            ValExpr(NoPos, NumVal(2.0))))));

      (Some("let assignment"),
      "let a = b - 2; a - 4",
      Ok(StmtProgram(NoPos, LetStmt(NoPos, "a",
                              BopExpr(NoPos,
                                        VarExpr(NoPos, "b"),
                                                MinusBop,
                                                  ValExpr(NoPos, NumVal(2.0)))),
                                                  ExprProgram(NoPos,
                                                  BopExpr(NoPos,
                                                    VarExpr(NoPos, "a"),
                                                      MinusBop,
                                                      ValExpr(NoPos, NumVal(4.0)))))));

      (Some("Unary Division"),
      "10 / 2",
      Ok(ExprProgram(NoPos, BopExpr(NoPos, ValExpr(NoPos, NumVal(10.0)), DivBop, ValExpr(NoPos, NumVal(2.0)))))
      );

      (Some("Multiplication, division, parenthesis precedence"),
      "(8 * 4) / (2 * 2)",
      Ok(ExprProgram(NoPos, BopExpr(NoPos, 
          BopExpr(NoPos, ValExpr(NoPos, NumVal(8.0)), TimesBop, ValExpr(NoPos, NumVal(4.0))), 
          DivBop, 
          BopExpr(NoPos, ValExpr(NoPos, NumVal(2.0)), TimesBop, ValExpr(NoPos, NumVal(2.0)))
      ))));

      (Some("Variable declaration and assignment"),
      "const a = 5; let b = a * 2;",
      Ok(StmtProgram(NoPos, ConstStmt(NoPos, "a", ValExpr(NoPos, NumVal(5.0))),
          StmtProgram(NoPos, LetStmt(NoPos, "b", BopExpr(NoPos, VarExpr(NoPos, "a"), TimesBop, ValExpr(NoPos, NumVal(2.0)))), ExprProgram(NoPos, ValExpr(NoPos, UndefVal))))));
         
      (Some("Unary negation"),
      "let notTrue = !true;",
      Ok(StmtProgram(NoPos, LetStmt(NoPos, "notTrue", UopExpr(NoPos, NotUop, ValExpr(NoPos, BoolVal(true)))), ExprProgram(NoPos, ValExpr(NoPos, UndefVal)))));

      (Some("Unary op on variable"),
      "let x = -5; -x",
      Ok(StmtProgram(NoPos, LetStmt(NoPos, "x", UopExpr(NoPos, NegUop, ValExpr(NoPos, NumVal(5.0)))), ExprProgram(NoPos, UopExpr(NoPos, NegUop, VarExpr(NoPos, "x"))))));

  ])

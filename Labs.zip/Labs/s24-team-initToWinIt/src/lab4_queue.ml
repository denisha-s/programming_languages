open Util (* see util.ml *)
open Lab4_lazy
open Lab4_stream

(****************)
(* Starter Code *)
(****************)

module Queue = struct

  (* These queues are based on Okasaki's BankersQueue, with the
     optimization noted on p.64 of using an ordinary list for the rear
     elements. *)

  (* front-length, front-elements, rear-length, rear-elements *)
  type 'a t =  int * 'a Stream.t * int * 'a list

  let empty() : 'a t  = (0, Stream.nil (), 0, [])

  exception Empty

  let rotate (q: 'a t) : 'a t  =
    let rec append_rev (f: 'a Stream.t) (r : 'a list) : 'a Stream.t  =
      (* return a stream of f followed by the reverse of r.  Only
         realize the reversal of r when we reach the end of f *)
      (let thunk () =
        match r with
        | [] -> Stream.Nil 
        | hd :: tl -> 
          let rec list_to_stream lst = match lst with
            | [] -> Stream.Nil
            | h :: t -> Stream.Cons(h, delay (fun () -> list_to_stream t))
          in
          list_to_stream (List.rev r)
       in delay thunk) in
    let (lenf, f, lenr, r) = q in
    (lenf+lenr, append_rev f r, 0, [])

  (* Invariant: rear length <= front length
     Implied Invariant: a non-empty queue always has a non-empty front stream *)
  let check (q:'a t) : 'a t =
      let (lenf, f, lenr, r) = q in
      if lenr <= lenf then q
      else
        let new_f = Stream.append f (Stream.from_list (List.rev r)) in
        (lenf + lenr, new_f, 0, [])

  let is_empty (q : 'a t) =
    let (lenf, _, _, _) = q in (lenf=0)

  let snoc (q:'a t) (x:'a) : 'a t =
    let (lenf, f, lenr, r) = q in
    (lenf, f, lenr + 1, x :: r)

  let head (q:'a t) : 'a =
    let (_, f, _, _) = q in
    match force f with
    | Stream.Cons(hd, _) -> hd
    | Stream.Nil -> raise Empty

  let tail (q:'a t) : 'a t =
    let (_, f, _, _) = q in
    match force f with
    | Stream.Cons(_, tl) -> check (0, tl, 0, [])
    | Stream.Nil -> raise Empty

  let rec fold_right (f : 'a -> 'acc -> 'acc ) (q : 'a t) (acc : 'acc) : 'acc =
    let (lenf, front, lenr, rear) = q in
    let acc_from_rear = List.fold_left (fun acc x -> f x acc) acc (List.rev rear) in
    Stream.fold_right f front acc_from_rear

  let from_lists (f : 'a list) (r : 'a list) : 'a t =
    (List.length f, Stream.from_list f, List.length r, r)

  let to_lists (q:'a t) : (int*'a list*int*'a list)  =
    let (lf, f, lr, r) = q in
    (lf, Stream.to_list f, lr, r)

  let from_list (l : 'a list) : 'a t =
    List.fold_left snoc (empty()) l

  let rec to_list (q : 'a t) : 'a list =
    fold_right (fun x l -> x :: l) q []
    
end

;;

(*********)
(* Tests *)
(*********)

(* to/from list *)
let queue_fromto_list_tester x = Queue.to_list (Queue.from_list x)
let queue_fromto_list_printer = Some(str_int_list,str_int_list)
let queue_fromto_list_tests =
  ("queue_fromto_list",
   queue_fromto_list_tester, (=), (=),
   queue_fromto_list_printer,
   [
     (None, [1;2;3], Ok [1;2;3]);
     (None, [1], Ok [1]);
     (None, [], Ok []);
  ])

(* to/from lists *)
let queue_fromto_lists_tester (f,r) =
  Queue.to_lists (Queue.from_lists f r)

let queue_lists_printer =
  str_tuple4 string_of_int str_int_list string_of_int str_int_list

let queue_fromto_lists_printer =
  Some(str_pair str_int_list str_int_list,
       queue_lists_printer)

let queue_fromto_lists_tests =
  ("queue_fromto_lists",
   queue_fromto_lists_tester, (=), (=),
   queue_fromto_lists_printer,
   [
     (None, ([1;2;3],[4;5]), Ok (3,[1;2;3],2,[4;5]));
     (None, ([1;2;3],[4;5;6]), Ok (3,[1;2;3],3,[4;5;6]));
     (None, ([1;2;3],[]), Ok (3,[1;2;3],0,[]));
     (None, ([],[]), Ok (0,[],0,[]));
  ])



(* head *)
let queue_head_tester (f,r) =
  Queue.head (Queue.from_lists f r)
let queue_head_printer =
  Some(str_pair str_int_list str_int_list,
       string_of_int)
let queue_head_tests =
  ("queue_head",
   queue_head_tester, (=), (=),
   queue_head_printer,
   [
     (None, ([3;4],[4;5]), Ok 3);
     (None, ([1;2;3],[]), Ok 1);
     (None, ([1],[]), Ok 1);
     (None, ([5],[1;2;3]), Ok 5);
  ])

(* check *)
let queue_check_tester (f,r) =
  Queue.to_lists (Queue.check (Queue.from_lists f r))
let queue_check_printer =
  Some(str_pair str_int_list str_int_list, queue_lists_printer)
let queue_check_tests =
  ("queue_check",
   queue_check_tester, (=), (=),
   queue_check_printer,
   [
     (None, ([2;3],[5;4]), Ok(2,[2;3],2,[5;4]));
     (None, ([1;2;3],[]), Ok(3,[1;2;3],0,[]));
     (None, ([4;5;6],[1;2;3]), Ok(3,[4;5;6],3,[1;2;3]));
     (None, ([7;8;9],[]), Ok(3,[7;8;9],0,[]));
  ])

(* snoc *)
let queue_snoc_tester (f,r,x) =
  Queue.to_lists (Queue.snoc (Queue.from_lists f r) x)
let queue_snoc_printer =
  Some(str_tuple3 str_int_list str_int_list string_of_int,
       queue_lists_printer)
let queue_snoc_tests =
  ("queue_snoc",
   queue_snoc_tester, (=), (=),
   queue_snoc_printer,
   [
     (None, ([1;2],[3],4), Ok (2,[1;2],2,[4;3]));
     (None, ([],[],7), Ok (0,[],1,[7]));
     (None, ([1;2;3],[4;5;6],7), Ok (3,[1;2;3],4,[7;4;5;6]));
     (None, ([1;2],[3],4), Ok (2,[1;2],2,[4;3]));
  ])

(* tail *)
let queue_tail_tester (f,r) =
  Queue.to_lists (Queue.tail (Queue.from_lists f r))
let queue_tail_printer =
  Some(str_pair str_int_list str_int_list, queue_lists_printer)
let queue_tail_tests =
  ("queue_tail",
   queue_tail_tester, (=), (=),
   queue_tail_printer,
   [
     (None, ([1;2],[4;3]), Ok(3,[2;3;4],0,[]));
     (* TODO *)
  ])

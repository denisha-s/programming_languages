open Util (* see util.ml *)
open Lab4_lazy

(****************)
(* Starter Code *)
(****************)

module Stream = struct
  type 'a cell =
    | Cons of 'a * 'a t
    | Nil
  and 'a t = ('a cell) suspension

  exception IndexError

  (* Return the head element of the list *)
  let head(l : 'a t) : 'a  =
    match force l with
    | Cons (x, _) -> x
    | Nil -> raise IndexError

  (* Return the tail of the list *)
  let tail(l : 'a t) : 'a t  =
    match force l with
    | Cons (_, tl) -> tl
    | Nil -> raise IndexError

  let nil()  = delay(fun () -> Nil)

  (* Create stream from the elements of a list *)
  let rec from_list (l : 'a list) : 'a t =
    match l with
    | [] -> delay (fun () -> Nil)
    | hd :: tl -> delay (fun () -> Cons (hd, from_list tl))

  (* Fold function f over the stream from the right (end) of the stream. *)
  (* fold_right is a monolithic function *)
  let rec fold_right (f : 'a->'acc->'acc) (s : 'a t) (acc : 'acc) : 'acc =
    match force s with
    | Nil -> acc
    | Cons (x, xs) -> f x (fold_right f xs acc)

  let rec to_list s =
    fold_right (fun x l -> x :: l) s []

  (* Create a stream by applying function f to produce successive elements. *)
  (* applying f to element i will produce element i+1 *)
  let rec seed (f : 'a -> 'a) (x : 'a) =
    delay (fun () -> Cons (x, seed f (f x)))

  (* Create a stream by applying function f to produce successive elements. *)
  (* applying f to (x_i,y_i) will produce (x_{i+1}, y_{i+1}), where
     each x represents stream elements and each y some additional
     parameter *)
  let rec seed2 (f : ('a*'b) -> ('a*'b)) ((x,y) : ('a *'b)) =
    delay (fun () -> Cons(x, seed2 f (f (x,y))))

  (* Append two streams *)
  let rec append (s1 : 'a t) (s2 : 'a t) : 'a t =
    delay (fun () ->
    match force s1 with
    | Cons (hd, tl) -> Cons (hd, append tl s2)
    | Nil -> force s2
  )

  (* Reverse a stream. *)
  (* reverse is a monolithic function *)
  let reverse (s : 'a t) : 'a t =
    (* recursively build a new stream in reverse order *)
    let rec reverse' (s : 'a t) (acc : 'a t) : 'a t =
      match force s with
      | Nil -> acc
      | Cons (hd, tl) -> reverse' tl (delay (fun () -> Cons (hd, acc)))
    in reverse' s (delay (fun () -> Nil))

  (* Return the nth element of the stream *)
  let rec nth(l : 'a t) (n:int) : 'a =
    if 0 = n
    then head l
    else nth (tail l) (n-1)

  (* Return a stream containing the first n elements of the input stream *)
  let rec prefix (l:'a t) (n:int) : 'a t =
    match n with
  | 0 -> delay(fun () -> Nil) (* Base case: Return an empty stream *)
  | _ -> (* Recursive case: Take elements from the input stream *)
    match force l with
    | Cons (hd, tl) -> delay(fun () -> Cons (hd, prefix tl (n - 1)))
    | Nil -> delay(fun () -> Nil) (* If the input stream is empty, return an empty stream *)

  let rec suffix (l:'a t) (n:int) : 'a t =
    if n <= 0 then l
    else suffix (tail l) (n-1)

  let rec sublist (l:'a t) (start:int) (stop:int) : 'a list =
    to_list (prefix (suffix l start) (stop - start))

  (* Map a function over a stream *)
  let rec map (f : 'x -> 'y) (l : 'x t): 'y t =
    delay (fun () ->
    match force l with
    | Nil -> Nil
    | Cons(x, xs) -> Cons(f x, map f xs))

  (* Map a function over two streams *)
  let rec map2 (f : 'x -> 'y -> 'z) (l1 : 'x t) (l2 : 'y t)
          : 'z t =
    delay (fun () ->
    match force l1, force l2 with
    | Cons(x, xs), Cons(y, ys) -> Cons(f x y, map2 f xs ys)
    | _, _ -> Nil)

  (* Filter a stream *)
  let rec filter  (f : 'x -> bool) (l : 'x t) : 'x t =
    delay (fun () ->
    match force l with
    | Nil -> Nil
    | Cons(x, xs) ->
      if f x
      then Cons(x, filter f xs)
      else force (filter f xs))

end

;;
(*********)
(* Tests *)
(*********)

(* to/from list *)
let stream_fromto_list_tester x = Stream.to_list (Stream.from_list x)
let stream_fromto_list_printer = Some(str_int_list,str_int_list)
let stream_fromto_list_tests =
  ("stream_fromto_list",
   stream_fromto_list_tester, (=), (=),
   stream_fromto_list_printer,
   [
     (None, [1;2;3], Ok [1;2;3]);
     (None, [1], Ok [1]);
     (None, [], Ok []);
  ])

(* seed tests *)
let stream_seed_tester (f,x,n) = Stream.to_list (Stream.prefix (Stream.seed f x) n)
let stream_seed_printer = Some((fun (f,x,n) -> string_of_int x), str_int_list)
let stream_seed_tests =
  ("seed",
   stream_seed_tester, (=), (=),
   stream_seed_printer,
   [
     (Some "nats", ((fun x -> 1+x), 0, 5), Ok [0;1;2;3;4]);
     (Some "xorshift32",
      ((fun x ->
        let bits32 = 0xffffffff in
        let x = ((x lsl 13) lxor x) land bits32 in
        let x = ((x lsr 17) lxor x) land bits32 in
        let x = ((x lsl  5) lxor x) land bits32 in
        x),
       42, 5),
      Ok [42; 11355432; 2836018348; 476557059; 3648046016]);
     (Some "zeno", ((fun x -> x / 2), 256, 5), Ok [256;128;64;32;16]);
  ])

let stream_seed2_tester (f,xi,n) = Stream.to_list (Stream.prefix (Stream.seed2 f xi) n)
let stream_seed2_printer = Some((fun (f,xi,n) -> str_pair string_of_int string_of_int xi),
                                str_int_list)
let stream_seed2_tests =
  ("seed2",
    stream_seed2_tester, (=), (=),
    stream_seed2_printer,
    [
      (Some "fact", ((fun (x,i) -> (x*i,i+1)), (1,1), 5), Ok [1; 1; 2; 6; 24]);
      (Some "fib", ((fun (x,xm) -> (xm,x+xm)), (0,1), 8), Ok [0; 1; 1; 2; 3; 5; 8; 13]);
   ])

let stream_append_tester (a,b) =
  Stream.to_list(Stream.append
                    (Stream.from_list a)
                    (Stream.from_list b))
let stream_append_printer = Some(str_pair str_int_list str_int_list, str_int_list)
let stream_append_tests =
  ("stream_append",
   stream_append_tester, (=), (=),
   stream_append_printer,
   [
     (None, ([1;2;3],[4;5;6]), Ok [1;2;3;4;5;6]);
     (None, ([],[4;5;6]), Ok [4;5;6]);
     (None, ([1;2;3],[]), Ok [1;2;3]);
     (None, ([],[1;2;3]), Ok [1;2;3]);
  ])


(* reverse *)
let stream_reverse_tester x = Stream.to_list (Stream.reverse (Stream.from_list x))
let stream_reverse_printer = Some(str_int_list,str_int_list)
let stream_reverse_tests =
  ("stream_reverse_list",
   stream_reverse_tester, (=), (=),
   stream_reverse_printer,
   [
     (None, [1;2;3], Ok [3;2;1]);
     (None, [1], Ok [1]);
     (None, [], Ok []);
     (None, [1;2;3;4;5], Ok [5;4;3;2;1]);
     (None, [1;2;3;4], Ok [4;3;2;1]);
     (None, [1;2;3;3;2;1], Ok [1;2;3;3;2;1]);
  ])


(* nth *)
let stream_nth_tester (x,n) = Stream.nth (Stream.from_list x) n
let stream_nth_printer = Some(str_pair str_int_list string_of_int,string_of_int)
let stream_nth_tests =
  ("stream_nth",
   stream_nth_tester, (=), (=),
   stream_nth_printer,
   [
     (None, ([0;1;2],1), Ok 1);
     (None, ([1;2;3],2), Ok 3);
     (None, ([1;2;3],3), Error Stream.IndexError);
     (None, ([],1), Error Stream.IndexError);
     (None, ([42],0), Ok 42);
  ])

(* prefix *)
let stream_prefix_tester (x,n) = Stream.to_list (Stream.prefix (Stream.from_list x) n)
let stream_prefix_printer = Some(str_pair str_int_list string_of_int,str_int_list)
let stream_prefix_tests =
  ("stream_prefix",
   stream_prefix_tester, (=), (=),
   stream_prefix_printer,
   [
     (None, ([0;1;2],2), Ok [0;1]);
     (None, ([], 0), Ok []);
     (None, ([1], 1), Ok [1]);
     (None, ([10; 20; 30; 40; 50], 3), Ok [10; 20; 30]);
  ])

(* suffix *)
let stream_suffix_tester (x,n) = Stream.to_list (Stream.suffix (Stream.from_list x) n)
let stream_suffix_printer = Some(str_pair str_int_list string_of_int,str_int_list)
let stream_suffix_tests =
  ("stream_suffix",
   stream_suffix_tester, (=), (=),
   stream_suffix_printer,
   [
     (None, ([0;1;2],0), Ok [0;1;2]);
     (None, ([], 0), Ok []);
     (None, ([1; 2; 3; 4; 5], 3), Ok [4; 5]);
     (None, ([10; 20; 30; 40; 50], 2), Ok [30; 40; 50]);
  ])

(* map *)
let stream_map_tester (f,x) = Stream.to_list (Stream.map f (Stream.from_list x))
let stream_map_printer = Some((fun (f,x) -> str_int_list x), str_int_list)
let stream_map_tests =
  ("stream_map",
   stream_map_tester, (=), (=),
   stream_map_printer,
   [
     (None, ((fun x->1+x), [0;1;2]), Ok [1;2;3]);
     (None, ((fun x->x*2), [1;2;3]), Ok [2;4;6]);
     (None, ((fun x->x*x), [1;2;3]), Ok [1;4;9]);
     (None, ((fun x -> x mod 2), [1;2;3;4;5]), Ok [1;0;1;0;1])
  ])

(* map2 *)
let stream_map2_tester (f,x,y) = Stream.to_list (Stream.map2 f (Stream.from_list x) (Stream.from_list y))
let stream_map2_printer = Some((fun (f,x,y) -> str_pair str_int_list str_int_list (x,y)), str_int_list)
let stream_map2_tests =
  ("stream_map2",
   stream_map2_tester, (=), (=),
   stream_map2_printer,
   [
     (None, ((+), [0;1;2], [4;5;6]), Ok [4;6;8]);
     (None, (( * ), [1;2;3], [4;5;6]), Ok [4;10;18]);
     (None, ((fun x y -> x - y), [10;8;6], [1;2;3]), Ok [9;6;3]);
     (None, ((fun x y -> x mod y), [10;20;30], [3;4;5]), Ok [1;0;0]);
  ])

(* filter *)
let stream_filter_tester (f,x) = Stream.to_list (Stream.filter f (Stream.from_list x))
let stream_filter_printer = Some((fun (f,x) -> str_int_list x), str_int_list)
let stream_filter_tests =
  ("stream_filter",
   stream_filter_tester, (=), (=),
   stream_filter_printer,
   [
     (None, ((fun x-> (x mod 2) = 0), [0;1;2;3;4;5;6]), Ok [0;2;4;6]);
     (None, ((fun x -> x >= 0), [-5; -1; 0; 1; 5]), Ok [0; 1; 5]);
     (None, ((fun x -> x > 10 && (x mod 2) = 0), [8; 11; 12; 14; 15]), Ok [12; 14]);
     (None, ((fun x -> x < 5 && (x mod 2) <> 0), [0; 2; 3; 4; 5; 7]), Ok [3]);
     (None, ((fun x -> (x mod 2) = 0 && (x mod 3) = 0), [6; 7; 8; 9; 12; 14]), Ok [6; 12]);
     (None, ((fun x -> x <> 0), [0; -1; 0; 1; 0; 2]), Ok [-1; 1; 2]);

  ])

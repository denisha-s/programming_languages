open Util (* see util.ml *)

(******************)
(** Starter Code **)
(******************)

exception IndexError

(* Return the i'th element of a list *)
let rec nth (i : int)  (l: 'a list) : 'a =
  match l with
    [] -> raise IndexError
  | a::d ->  (match i with
              | 0 -> a
              | _ -> nth (i-1)d)

(* Append two lists *)
let rec append (l1 : 'a list) (l2: 'a list) : 'a list =
  match (l1, l2) with
  | [], [] -> []
  | a::b, [] -> l1
  | [], a::b -> l2
  | l1first::l1rest, l2first::l2rest -> l1first::append l1rest l2 (*This is a test... it should work*)

(* Reverse a list *)
let rec reverse (l : 'a list) : 'a list =
  match l with
  | [] -> []
  | hd::tl -> append (reverse tl) [hd]

(* Length of a list *)
let rec length (l : 'a list) : int  =
  match l with
  | [] -> 0
  | _::d -> 1 + length d


(* Return the part of list l beginning at index 0 and ending at index
   iend *)
let rec list_prefix (iend : int) (l : 'a list) : 'a list =
  if iend < 0 then raise IndexError
  else if iend = 0 then []
  else
    match l with
      [] -> if iend = 0 then []
            else raise IndexError
    | a::d ->
       a :: list_prefix (iend-1) d

(* Return the part of list l beginning at istart and running through
   the end of the list *)
let rec list_suffix (istart : int) (l : 'a list) : 'a list =
  if istart < 0 then raise IndexError
  else
    match l with
    | [] -> if istart > 0 then raise IndexError else []
    | hd::tl -> if istart = 0 then l else list_suffix (istart-1) tl

(* Merge sorted lists l1 and l2 based on cmp.  The result is a sorted
   list containing all elements from both l2 and l2. *)
let rec merge (cmp : 'a->'a->bool) (l1 : 'a list) (l2 : 'a list) : 'a list =
  match (l1, l2) with
  | [], _ -> l2
  | _, [] -> l1
  | hd1::tl1, hd2::tl2 ->
    if cmp hd1 hd2 then hd1 :: merge cmp tl1 l2 
    else hd2 :: merge cmp l1 tl2

(* Sort list l via mergesort

   cmp is a function that compares two elements of list l.  When cmp
   returns true, its first argument comes first in the sorted lest.
   When cmp returns false, its second argument comes first in the
   sorted list.  *)
let rec mergesort (cmp : 'a -> 'a -> bool) (l : 'a list) : 'a list =
  match l with
  | [] -> [] 
  | [x] -> [x]
  | _ ->
    let rec split l =
      match l with
      | [] -> ([], [])
      | [x] -> ([x], [])
      | x :: y :: rest -> let (left, right) = split rest in (x :: left, y :: right)
    in
    let left, right = split l in
    merge cmp (mergesort cmp left) (mergesort cmp right)

(***********)
(** Tests **)
(***********)

(* See description in testing.ml *)

let nth_tests =
  ("Nth", (fun (i,l)->nth i l), (=), (=),
   Some((fun x -> str_pair string_of_int str_int_list x),
        string_of_int),
   [
     (Some("simple list"), (0, [1;2;3;4;5]), Ok 1);
     (Some("error"), (-1, [1;2;3;4;5]), Error IndexError);
     (Some("last element"), (4, [1;2;3;4;5]), Ok 5);
     (Some("middle element"), (2, [1;2;3;4;5]), Ok 3);
     (Some("after list"), (5, [1;2;3;4;5]), Error IndexError);
     (Some("empty list"), (0, []), Error IndexError);
     (Some("one element"), (0, [4]), Ok 4);
  ])

let append_tests =
  ("append", (fun (l1,l2)->append l1 l2), (=), (=),
   Some((fun x -> str_pair str_int_list  str_int_list x),
        str_int_list),
   [
     (Some("simple list"), ([1;2],[3;4]), Ok [1;2;3;4]);
     (Some("empty lists"), ([],[]), Ok []);
     (Some("first empty"), ([],[1;3;4]), Ok [1;3;4]);
     (Some("second empty"), ([1;2;3],[]), Ok [1;2;3]);
     (Some("longer unsorted"), ([1;3;6;10],[3;7;8;14]), Ok [1;3;6;10;3;7;8;14]);
     (Some("duplicates"), ([2;2;2],[2;2;2]), Ok [2;2;2;2;2;2]);
  ])

let reverse_tests =
  ("reverse", reverse, (=), (=), Some(str_int_list,str_int_list),
   [
     (Some("simple list"), [1;2;3;4;5], Ok[5;4;3;2;1]);
     (Some("simple even list"), [1;2;3;4;5;6], Ok[6;5;4;3;2;1]);
     (Some("palindrome list"), [1;2;3;2;1], Ok[1;2;3;2;1]);
     (Some("palindrome even list"), [1;2;3;3;2;1], Ok[1;2;3;3;2;1]);
     (Some("single element list"), [1;1;1;1;1], Ok[1;1;1;1;1]);
     (Some("single element even list"), [1;1;1;1;1;1], Ok[1;1;1;1;1;1]);
  ])

let length_tests =
  ("length", length, (=), (=), Some(str_int_list,string_of_int),
   [
     (Some("simple list"), [1;2;3;4;5], Ok 5);
     (Some("simple list 2"), [1], Ok 1);
     (Some("empty list"), [], Ok 0);
     (Some("jumbled list"), [5; 3; 1; 2; 4], Ok 5);
     (Some("large list"), [1;2;3;4;5; 7; 8; 9; 10; 11; 12; 13; 14; 15], Ok 14);
     (Some("large jumbled list"), [1;2;3;4;5; 10; 25; 24; 27; 97; 100; 9; 21], Ok 13);
  ])

let list_prefix_tests =
  ("list_prefix", (fun (iend,l) -> list_prefix iend l), (=), (=),
   Some((fun x -> str_pair string_of_int  str_int_list x),
        str_int_list),
   [
     (Some("simple list"), (2,[1;2;3;4;5]), Ok [1;2]);
     (None, (0,[1;2;3;4;5]), Ok []);
     (None, (4,[1;2;3;4;5]), Ok [1;2;3;4]);
     (None, (5,[1;2;3;4;5]), Ok [1;2;3;4;5]);
     (None, (-1,[1;2;3;4;5]), Error IndexError);
     (None, (6,[1;2;3;4;5]), Error IndexError);
     (None, (10,[1;2;3;4;5]), Error IndexError);
  ])

let list_suffix_tests =
  ("list_suffix", (fun (istart,l) -> list_suffix istart l), (=), (=),
   Some((fun x -> str_pair string_of_int  str_int_list x),
        str_int_list),
   [
     (Some("simple list"), (2,[1;2;3;4;5]), Ok [3;4;5]);
     (Some("negative start"), (-1,[1;2;3;4;5]), Error IndexError);
     (Some("start at length"), (5,[1;2;3;4;5]), Ok []);
     (Some("start beyond length"), (6,[1;2;3;4;5]), Error IndexError);
     (Some("start at zero"), (0,[1;2;3;4;5]), Ok [1;2;3;4;5]);
     (Some("repeated elements"), (2,[1;1;1;1;1]), Ok [1;1;1]);
  ])

let merge_tests =
  ("merge", (fun (cmp,l1,l2) -> merge cmp l1 l2), (=), (=),
   Some((fun (cmp,l1,l2) -> str_pair str_int_list str_int_list (l1, l2)),
        str_int_list),
   [
     (Some("simple list"), ((<),[1;3],[2;4;5]), Ok [1;2;3;4;5]);
     (Some("both empty"), ((<),[],[]), Ok []);
     (Some("first empty"), ((<),[],[1;2;3]), Ok [1;2;3]);
     (Some("second empty"), ((<),[1;2;3],[]), Ok [1;2;3]);
     (Some("descending order"), ((>),[3;2;1],[5;4]), Ok [5;4;3;2;1]);
     (Some("repeated elements"), ((<),[1;3;3],[2;2;4]), Ok [1;2;2;3;3;4]);
  ])


let mergesort_tests =
  ("mergesort", (fun (cmp,l) -> mergesort cmp l), (=), (=),
   Some((fun (cmp,l) -> str_int_list l),
        str_int_list),
   [
     (Some("simple list"), ((<),[1;3;4;2;5]), Ok [1;2;3;4;5]);
     (Some("already sorted asc"), ((<),[1;2;3;4;5]), Ok [1;2;3;4;5]);
     (Some("sorted desc"), ((<),[5;4;3;2;1]), Ok [1;2;3;4;5]);
     (Some("all equal elements"), ((<),[3;3;3;3;3]), Ok [3;3;3;3;3]);
     (Some("empty list"), ((<),[]), Ok []);
     (Some("mixed negative and positive"), ((<),[-1;3;-2;4;0]), Ok [-2;-1;0;3;4]);
   ])

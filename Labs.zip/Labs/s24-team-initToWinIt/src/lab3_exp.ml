open Util (* see util.ml *)

(********************************)
(* PART I: Arithmetic Evaluator *)
(********************************)

type bop = Add | Sub | Mul | Div

(* Reverse Polish Notation (RPN) *)
module RPN = struct
  type cmd =
    | Op of bop
    | Num of int

  type exp = cmd list

  (* RPN evaluator.  Return the stack after evaluating commands. *)
  let eval (cmds : exp) : int list =
    List.fold_left
      (fun stack cmd -> match cmd with
      | Num x -> x :: stack         (* if we get an int, push it into the stack *)
      | Op op -> match stack with   (* for ops, apply it to the front two numbers in the stack *)
                 | x :: y :: rest -> let result =      (* only matches with 2+ elements *)
                    if op = Add then x + y
                    else if op = Sub then y - x
                    else if op = Mul then x * y
                    else if op = Div then 
                    (if x = 0 then raise (Invalid_argument "Div0") else y / x)
                    else raise (Invalid_argument "InvalidOp")
                 in result :: rest
                 | _ -> raise (Invalid_argument "rpn") (* if stack doesn't have 2+ elements *)
      )
      [] cmds

  let string cmds =
    "[" ^ str_x_list (fun cmd -> match cmd with
                                 | Op Add -> "+"
                                 | Op Sub -> "-"
                                 | Op Mul -> "*"
                                 | Op Div -> "/"
                                 | Num x -> string_of_int x)
            cmds ";" ^ "]"

end



(* Expression Trees *)
module Exp = struct
  type exp =
    | BinExp of bop * exp * exp
    | Num of int

  (* Evaluate the expression *)
  let rec eval (e : exp) : int =
    match e with
    | Num x -> x
    | BinExp(op,e1,e2) ->
       let x = eval e1 in
       let y = eval e2 in (* make e1 and e2 into Nums *)
       match op with
       | Add -> x + y
       | Sub -> x - y
       | Mul -> x * y
       | Div -> 
          if y = 0 then raise (Invalid_argument "Div0") else x / y 

  (* Convert the expression to a string.  The string must be fully
   parenthesized and contain no whitespace. *)
  let rec string (e : exp) : string =
    match e with
    | Num x -> string_of_int x
    | BinExp(op,e1,e2) ->
       "("
       ^ (string e1)
       ^ (match op with
          | Add -> "+"
          | Sub -> "-"
          | Mul -> "*"
          | Div -> "/")
       ^ (string e2)
       ^ ")"

  (* Convert the infix expression to the equivalent rpn expression. *)
  let rec rpn (e : exp) : RPN.exp =
    match e with
    | Num x -> [RPN.Num x]
    | BinExp(op,e1,e2) ->
       (rpn e1)
       @ (rpn e2)
       @ [RPN.Op op]

end

(*********)
(* Tests *)
(*********)

let exp_string_tests =
  ("Exp.string",
   Exp.string, (=), (=),
   Some (Exp.string, fun x->x),
   [
     (Some "Simple Num", Exp.Num 1, Ok "1");
     (Some "Simple Exp", Exp.BinExp(Add, Exp.Num 1, Exp.Num 2), Ok "(1+2)");
     (Some "Exp Commutativity",  Exp.BinExp(Sub, Exp.Num 1, Exp.Num 2), Ok "(1-2)");
   ])


let exp_rpn_tests =
  ("Exp.rpn",
   Exp.rpn, (=), (=),
   Some (Exp.string, RPN.string),
   [
     (Some "Simple Exp.Num", Exp.Num 1, Ok [RPN.Num 1]);
     (Some "Simple Exp", BinExp(Add, Exp.Num 1, Exp.Num 2), Ok [RPN.Num 1; RPN.Num 2; RPN.Op Add]);
     (Some "Another Exp", BinExp(Mul, BinExp(Add, Exp.Num 1, Exp.Num 2), Exp.Num 3),
      Ok [RPN.Num 1; RPN.Num 2; RPN.Op Add; RPN.Num 3; RPN.Op Mul]);
   ])


let rpn_eval_tests =
  ("RPN.eval",
   RPN.eval, (=), (=),
   Some(RPN.string, str_int_list),
   [
     (Some "Simple RPN", [RPN.Num 1; RPN.Num 2; RPN.Op Add], Ok [3]);
     (Some "RPN Inval", [RPN.Num 1; RPN.Op Add], Error (Invalid_argument "rpn"));
     (Some "RPN Commutativity", [RPN.Num 1; RPN.Num 2;  RPN.Op Sub], Ok [-1]);
     (Some "More RPN", [RPN.Num 1; RPN.Num 2; RPN.Num 3;  RPN.Op Sub; RPN.Num 4;  RPN.Op Add], Ok [3; 1]);
     (Some "Divide By Zero", [RPN.Num 10; RPN.Num 0; RPN.Op Div], Error (Invalid_argument "Div0"));
     (Some "Somewhat Complex Operation", [RPN.Num 10; RPN.Num 2; RPN.Op Mul; RPN.Num 5; RPN.Op Add], Ok [25]);
     (Some "Lonely Op-less Number", [RPN.Num 42], Ok [42]);
     (Some "Nested Operations", [RPN.Num 5; RPN.Num 1; RPN.Num 2; RPN.Op Add; RPN.Op Mul], Ok [15]);
     (Some "Little Bit of Everything", [RPN.Num 20; RPN.Num 5; RPN.Op Div; RPN.Num 3; RPN.Op Add; RPN.Num 2;
      RPN.Op Mul], Ok [14]);
   ])


let exp_eval_tests =
  ("Exp.eval",
   Exp.eval, (=), (=),
   Some (Exp.string, string_of_int),
   [
     (Some "Simple Exp.Num", Exp.Num 1, Ok 1);
     (Some "Simple Exp", BinExp(Add, Exp.Num 1, Exp.Num 2), Ok 3);
     (Some "Exp Commutativity",  BinExp(Sub, Exp.Num 1, Exp.Num 2), Ok (-1));
     (Some "Nested Expression", BinExp(Mul, BinExp(Add, Exp.Num 1, Exp.Num 2), Exp.Num 3), Ok 9);
     (Some "Divide By Zero", BinExp(Div, Exp.Num 1, Exp.Num 0), Error (Invalid_argument "Div0"));
     (Some "Feel My Power (Of Two To The Third)", BinExp(Mul, Exp.Num 2, BinExp(Mul, Exp.Num 2, Exp.Num 2)), Ok 8);
     (Some "Complex Expression", BinExp(Add, BinExp(Mul, Exp.Num 2, Exp.Num 3), BinExp(Div, Exp.Num 10, Exp.Num 2)),
      Ok 11);
     (Some "All Operations", BinExp(Div, BinExp(Add, Exp.Num 10, BinExp(Mul, Exp.Num 2, Exp.Num 3)),
      Exp.Num 2), Ok 8);
   ])

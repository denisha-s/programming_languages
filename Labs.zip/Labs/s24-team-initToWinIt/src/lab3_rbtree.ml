open Util (* see util.ml *)

(*****************************)
(* PART II: Red-Black Trees *)
(*****************************)

module RBTree = struct
  type color = Red | Black
  type 'v tree =
    | Empty
    | Rnode of 'v tree * 'v * 'v tree (* Red node *)
    | Bnode of 'v tree * 'v * 'v tree (* Black node *)

  (* Return the color of an rbtree node *)
  let color t =
    match t with
      Rnode(_,_,_) -> Red
    | Bnode(_,_,_) | Empty -> Black

  (* Result of comparing two values *)
  (* if a < b, then cmp a b -> Lesser *)
  (* if a = b, then cmp a b -> Equal *)
  (* if a > b, then cmp a b -> Greater *)
  type cmp_result =
    | Lesser | Equal | Greater

  (* compare two data elements of type 'v *)
  type 'v cmp_fun = 'v -> 'v -> cmp_result

  (* Test if t satisfies the red-black tree invariants.
   *
   *  1. Does every red node have only black children?
   *  2. Does every path from root to leaf have the same number of black nodes?
   *)
  let is_invariant (t : 'v tree) : bool =
    let rec count_black tree count =
    match tree with
    | Empty -> (true, count)
    | Bnode(bl, bv, br) -> 
      let (bool1, left_count) = count_black bl (count+1) in
      let (bool2, right_count) = count_black br (count+1) in
      if (left_count = right_count) then ((bool1 && bool2), left_count) else (false, left_count)
    | Rnode(rl, rv, rr) -> 
      match (color rl, color rr) with
      | (Red, Red) | (Red, _) | (_, Red) -> (false, count)
      | (Black, Black) -> 
        let (bool1, left_count) = count_black rl count in
        let (bool2, right_count) = count_black rr count in
        if (left_count = right_count) then ((bool1 && bool2), left_count) else (false, left_count)
    in
    let (is_invariant, _) = count_black t 0 in
    is_invariant

  (* Test if red-black tree t is sorted. *)
  let rec is_sorted (cmp : 'v cmp_fun) (t : 'v tree) : bool =
    let rec h tree acc =
    match tree with
    | Empty -> []
    | Rnode(l, v, r) | Bnode(l, v, r) ->
      let left = h l acc in
      let right = h r [] in
      left @ v::right
    in
    let rec listcomp l prev=
      match (prev, l) with
      | _, [] -> true
      | _, h::t -> 
        if cmp prev h = Lesser then listcomp t h
        else false
      in
      let treelist = h t [] in
      match treelist with
      | [] -> true
      | h::t -> (listcomp t h)

  (* Search for element x in red-black tree t.
   *
   * Return true if the tree contains x and false if it does not. *)
  let rec search (cmp : 'v cmp_fun) (t : 'v tree) (x:'v) : bool =
    match t with
  | Empty -> false 
  | Rnode (left, value, right) | Bnode (left, value, right) ->
    match cmp x value with
    | Equal -> true 
    | Lesser -> search cmp left x
    | Greater -> search cmp right x

  (* Balance constructor for a red-black tree *)
  let balance (c:color) (l : 'v tree) (v : 'v ) (r : 'v tree) : 'v tree =
    match (c,l,v,r) with
    | Black,Rnode(Rnode(a,x,b),y,c),z,d
    | Black,Rnode(a,x,Rnode(b,y,c)),z,d
    | Black,a,x,Rnode(Rnode(b,y,c),z,d)
    | Black,a,x,Rnode(b,y,Rnode(c,z,d)) ->
      Rnode(Bnode(a,x,b),y,Bnode(c,z,d))
    | Black,l,v,r -> Bnode(l,v,r)
    | Red,l,v,r -> Rnode(l,v,r)

  (* Insert element x into a red-black tree
   *
   * Do not reinsert (duplicate) existing elements *)
  let insert (cmp : 'v cmp_fun) (t : 'v tree) (x:'v) : 'v tree =
    let rec h tree =
      match tree with
      | Empty -> Rnode(Empty, x, Empty)
      | Rnode(l, y, r) ->
        (match cmp x y with
        | Lesser -> balance Red (h l) y r
        | Greater -> balance Red l y (h r) 
        | _ -> tree)
      | Bnode(l, y, r) ->
        (match cmp x y with
        | Lesser -> balance Black (h l) y r
        | Greater -> balance Black l y (h r) 
        | _ -> tree)
    in
    match h t with
    | Rnode(l, y, r) -> Bnode(l, y, r)
    | rbt -> rbt


  (* Apply function f to every data element of tree t and collect the
   results in a list following an inorder traversal of the tree *)
  let rec map_inorder (f : 'v -> 'a) (t : 'v tree) : 'a list =
    match t with
    | Empty -> []
    | Rnode (left, value, right) | Bnode (left, value, right) ->
      let left_list = map_inorder f left in
      let current_value = f value in
      let right_list = map_inorder f right in
      left_list @ [current_value] @ right_list


  (* Apply function f to every data element of tree t and collect the
   results in a list following the reverse of an inorder traversal of the tree *)
  let rec map_revorder (f : 'v -> 'a) (t : 'v tree) : 'a list =
    match t with
    | Empty -> []
    | Rnode (left, value, right) | Bnode (left, value, right) ->
      let right_list = map_revorder f right in
      let current_value = f value in
      let left_list = map_revorder f left in
      right_list @ [current_value] @ left_list

end

(*********)
(* Tests *)
(*********)

(* See description in testing.ml *)

let int_cmp : int->int->RBTree.cmp_result =
  fun a b ->
  if a < b then RBTree.Lesser
  else if a > b then RBTree.Greater
  else RBTree.Equal

let str_cmp : string->string->RBTree.cmp_result =
  fun a b ->
  let c = compare a b in
  if c < 0 then RBTree.Lesser
  else if c > 0 then RBTree.Greater
  else RBTree.Equal

(* Convert tree to string *)
let rec str_x_rbtree f t =
  let h s l d r =
    Printf.sprintf "%s(%s,%s,%s)"
      s (str_x_rbtree f l) (f d) (str_x_rbtree f r)
  in
  match t with
  | RBTree.Empty -> "Empty"
  | RBTree.Rnode(l,d,r) ->
     h "Rnode" l d r
  | RBTree.Bnode(l,d,r) ->
     h "Bnode" l d r

let str_int_rbtree t = str_x_rbtree string_of_int t
let str_str_rbtree t = str_x_rbtree str_str t

let tree_arg_printer f =
  (fun (t,x) -> str_pair (str_x_rbtree f) f (t,x))

let int_tree_arg_printer = tree_arg_printer string_of_int
let str_tree_arg_printer = tree_arg_printer str_str

exception InvalidRBTreeError

(* To check that test case inputs are valid, sorted red-black trees *)
let check_rbtree (cmp : 'v RBTree.cmp_fun) (t: 'v RBTree.tree) =
  if (RBTree.is_invariant t) && (RBTree.is_sorted cmp t) then t
  else raise InvalidRBTreeError

(* To check that test case expected outputs are valid, sorted red-black trees *)
let eq_rbtree cmp_fun t1 t_expected =
  t1 = (check_rbtree cmp_fun t_expected)

(* Leaf node constants to make test inputs more readable *)
let r0 =  RBTree.Rnode(RBTree.Empty, 0,RBTree.Empty)
let r1 =  RBTree.Rnode(RBTree.Empty, 1,RBTree.Empty)
let r2 =  RBTree.Rnode(RBTree.Empty, 2,RBTree.Empty)
let r3 =  RBTree.Rnode(RBTree.Empty, 3,RBTree.Empty)
let r4 =  RBTree.Rnode(RBTree.Empty, 4,RBTree.Empty)
let r5 =  RBTree.Rnode(RBTree.Empty, 5,RBTree.Empty)
let r6 =  RBTree.Rnode(RBTree.Empty, 6,RBTree.Empty)
let r7 =  RBTree.Rnode(RBTree.Empty, 7,RBTree.Empty)
let r8 =  RBTree.Rnode(RBTree.Empty, 8,RBTree.Empty)
let r9 =  RBTree.Rnode(RBTree.Empty, 9,RBTree.Empty)
let r10 = RBTree.Rnode(RBTree.Empty,10,RBTree.Empty)
let r11 = RBTree.Rnode(RBTree.Empty,11,RBTree.Empty)
let r12 = RBTree.Rnode(RBTree.Empty,12,RBTree.Empty)
let r13 = RBTree.Rnode(RBTree.Empty,13,RBTree.Empty)
let r14 = RBTree.Rnode(RBTree.Empty,14,RBTree.Empty)
let r15 = RBTree.Rnode(RBTree.Empty,15,RBTree.Empty)
let r16 = RBTree.Rnode(RBTree.Empty,16,RBTree.Empty)
let r17 = RBTree.Rnode(RBTree.Empty,17,RBTree.Empty)
let r18 = RBTree.Rnode(RBTree.Empty,18,RBTree.Empty)
let r19 = RBTree.Rnode(RBTree.Empty,19,RBTree.Empty)
let r20 = RBTree.Rnode(RBTree.Empty,20,RBTree.Empty)
let r21 = RBTree.Rnode(RBTree.Empty,21,RBTree.Empty)
let r22 = RBTree.Rnode(RBTree.Empty,22,RBTree.Empty)
let r23 = RBTree.Rnode(RBTree.Empty,23,RBTree.Empty)
let r24 = RBTree.Rnode(RBTree.Empty,24,RBTree.Empty)
let r25 = RBTree.Rnode(RBTree.Empty,25,RBTree.Empty)
let r26 = RBTree.Rnode(RBTree.Empty,26,RBTree.Empty)
let r27 = RBTree.Rnode(RBTree.Empty,27,RBTree.Empty)
let r28 = RBTree.Rnode(RBTree.Empty,28,RBTree.Empty)
let r29 = RBTree.Rnode(RBTree.Empty,29,RBTree.Empty)
let r30 = RBTree.Rnode(RBTree.Empty,30,RBTree.Empty)
let r31 = RBTree.Rnode(RBTree.Empty,31,RBTree.Empty)
let r32 = RBTree.Rnode(RBTree.Empty,32,RBTree.Empty)
let r33 = RBTree.Rnode(RBTree.Empty,33,RBTree.Empty)
let r34 = RBTree.Rnode(RBTree.Empty,34,RBTree.Empty)

let b0 =  RBTree.Bnode(RBTree.Empty, 0,RBTree.Empty)
let b1 =  RBTree.Bnode(RBTree.Empty, 1,RBTree.Empty)
let b2 =  RBTree.Bnode(RBTree.Empty, 2,RBTree.Empty)
let b3 =  RBTree.Bnode(RBTree.Empty, 3,RBTree.Empty)
let b4 =  RBTree.Bnode(RBTree.Empty, 4,RBTree.Empty)
let b5 =  RBTree.Bnode(RBTree.Empty, 5,RBTree.Empty)
let b6 =  RBTree.Bnode(RBTree.Empty, 6,RBTree.Empty)
let b7 =  RBTree.Bnode(RBTree.Empty, 7,RBTree.Empty)
let b8 =  RBTree.Bnode(RBTree.Empty, 8,RBTree.Empty)
let b9 =  RBTree.Bnode(RBTree.Empty, 9,RBTree.Empty)
let b10 = RBTree.Bnode(RBTree.Empty,10,RBTree.Empty)
let b11 = RBTree.Bnode(RBTree.Empty,11,RBTree.Empty)
let b12 = RBTree.Bnode(RBTree.Empty,12,RBTree.Empty)
let b13 = RBTree.Bnode(RBTree.Empty,13,RBTree.Empty)
let b14 = RBTree.Bnode(RBTree.Empty,14,RBTree.Empty)
let b15 = RBTree.Bnode(RBTree.Empty,15,RBTree.Empty)
let b16 = RBTree.Bnode(RBTree.Empty,16,RBTree.Empty)
let b17 = RBTree.Bnode(RBTree.Empty,17,RBTree.Empty)
let b18 = RBTree.Bnode(RBTree.Empty,18,RBTree.Empty)
let b19 = RBTree.Bnode(RBTree.Empty,19,RBTree.Empty)
let b20 = RBTree.Bnode(RBTree.Empty,20,RBTree.Empty)

let ra =  RBTree.Rnode(RBTree.Empty,"a",RBTree.Empty)
let rb =  RBTree.Rnode(RBTree.Empty,"b",RBTree.Empty)
let rc =  RBTree.Rnode(RBTree.Empty,"c",RBTree.Empty)
let rd =  RBTree.Rnode(RBTree.Empty,"d",RBTree.Empty)

let re = RBTree.Rnode(RBTree.Empty, "e", RBTree.Empty)
let rf = RBTree.Rnode(RBTree.Empty, "f", RBTree.Empty)
let rg = RBTree.Rnode(RBTree.Empty, "g", RBTree.Empty)

let ba =  RBTree.Bnode(RBTree.Empty,"a",RBTree.Empty)
let bb =  RBTree.Bnode(RBTree.Empty,"b",RBTree.Empty)
let bc =  RBTree.Bnode(RBTree.Empty,"c",RBTree.Empty)
let bd =  RBTree.Bnode(RBTree.Empty,"d",RBTree.Empty)

let be =  RBTree.Bnode(RBTree.Empty,"e",RBTree.Empty)
let bf =  RBTree.Bnode(RBTree.Empty,"f",RBTree.Empty)
let bg =  RBTree.Bnode(RBTree.Empty,"g",RBTree.Empty)

let rbt_is_invariant_int_tests =
  ("rbt_is_invariant_int",
   RBTree.is_invariant,
   (=), (=),
   Some(str_int_rbtree,
        str_bool),
   [
     (Some("simple tree"),
      RBTree.Bnode(r1, 2, r3),
      Ok(true));
     (Some("empty tree"),
      Empty,
      Ok(true));
     (Some("large tree"),
      RBTree.Bnode(Rnode(b1, 2, b3), 4, Rnode(b5, 6, b7)),
      Ok(true));
     (Some("red root simple"),
      Rnode(b1, 2, b3),
      Ok(true));
     (Some("red with red child"),
      RBTree.Bnode(Rnode(r1, 2, b3), 4, Rnode(r5, 6, b7)),
      Ok(false));
     (Some("unequal black count"),
      RBTree.Bnode(RBTree.Bnode(r1, 2, r3), 4, RBTree.Bnode(RBTree.Bnode(r5, 6, r7), 8, r9)),
      Ok(false));
   ])

let rbt_is_invariant_str_tests =
  ("rbt_is_invariant_str",
   RBTree.is_invariant,
   (=), (=),
   Some(str_str_rbtree,
        str_bool),
   [
     (Some("simple tree"),
      RBTree.Bnode(ra, "b", rc),
      Ok(true));
     (Some("empty tree"),
      Empty,
      Ok(true));
     (Some("large tree"),
      RBTree.Bnode(Rnode(ba, "b", bc), "d", Rnode(be, "f", bg)),
      Ok(true));
     (Some("red root simple"),
      Rnode(ba, "b", bc),
      Ok(true));
     (Some("red with red child"),
      RBTree.Bnode(Rnode(ra, "b", bc), "d", Rnode(re, "f", bg)),
      Ok(false));
     (Some("unequal black count"),
      RBTree.Bnode(RBTree.Bnode(ra, "b", rc), "d", RBTree.Bnode(RBTree.Bnode(re, "f", rg), "h", Empty)),
      Ok(false));
   ])

let rbt_is_sorted_int_tests =
  ("rbt_is_sorted_int",
   (fun t -> RBTree.is_sorted int_cmp t),
   (=), (=),
   Some(str_int_rbtree,
        str_bool),
   [
     (Some("simple tree"),
      RBTree.Bnode(r1, 2, r3),
      Ok(true));
     (Some ("empty tree"),
      Empty,
      Ok(true));
     (Some("not sorted tree"),
      RBTree.Bnode(r2, 1, r3),
      Ok(false));
     (Some("large tree"),
      RBTree.Bnode(RBTree.Bnode(r1, 2, r3), 4, RBTree.Bnode(r5, 6, r7)),
      Ok(true));
     (Some("duplicates"),
      RBTree.Bnode(r2, 2, r3),
      Ok(false));
     (Some("larger skip numbers"),
      RBTree.Bnode(RBTree.Bnode(r1, 2, r4), 6, RBTree.Bnode(r7, 9, r11)),
      Ok(true));

   ])


let rbt_is_sorted_str_tests =
  ("rbt_is_sorted_str",
   (fun t -> RBTree.is_sorted str_cmp t),
   (=), (=),
   Some(str_str_rbtree,
        str_bool),
   [
     (Some("simple tree"),
      RBTree.Bnode(ra, "b", rc),
      Ok(true));
     (Some("empty tree"),
      Empty,
      Ok(true));
     (Some("not sorted tree"),
      RBTree.Bnode(rc, "a", rb),
      Ok(false));
     (Some("large tree"),
      RBTree.Bnode(RBTree.Bnode(ra, "b", rc), "d", RBTree.Bnode(re, "f", rg)),
      Ok(true));
     (Some("duplicates"),
      RBTree.Bnode(ra, "b", rb),
      Ok(false));
     (Some("larger skip letters"),
      RBTree.Bnode(RBTree.Bnode(ra, "b", rd), "f", RBTree.Bnode(rg, "h", Empty)),
      Ok(true));
   ])

let rbt_search_int_tests =
  ("rbt_search_int",
   (fun (t,x) -> RBTree.search int_cmp (check_rbtree int_cmp t) x),
   (=), (=),
   Some(int_tree_arg_printer, str_bool),
   [
     (Some("simple tree"),
      (RBTree.Bnode(r1, 2, r3), 2),
      Ok(true));
     (Some("big tree"),
      (RBTree.Bnode(RBTree.Bnode(r1, 2, r3), 4, RBTree.Bnode(r5, 6, r7)), 6),
      Ok(true));
     (Some("value not present"),
      (RBTree.Bnode(RBTree.Bnode(r1, 2, r3), 4, RBTree.Bnode(r5, 6, r7)), 8),
      Ok(false));
     (Some("empty tree"),
      (Empty, 1),
      Ok(false));
     (Some("leaf find"),
      (RBTree.Bnode(RBTree.Bnode(r1, 2, r3), 4, RBTree.Bnode(r5, 6, r7)), 7),
      Ok(true));
     (Some("value present in unbalanced tree"),
      (RBTree.Bnode(RBTree.Bnode(RBTree.Empty, 1, RBTree.Empty), 2, RBTree.Bnode(RBTree.Empty, 3, RBTree.Empty)), 2),
      Ok(true));
   ])

let rbt_search_str_tests =
  ("rbt_search_str",
   (fun (t,x) -> RBTree.search str_cmp (check_rbtree str_cmp t) x),
   (=), (=),
   Some(str_tree_arg_printer, str_bool),
   [
     (Some("simple tree"),
      (RBTree.Bnode(ra, "b", rc), "b"),
      Ok(true));
     (Some("big tree"),
      (RBTree.Bnode(RBTree.Bnode(RBTree.Rnode(Empty, "a", Empty), "b", RBTree.Rnode(Empty, "c", Empty)), "d",
      RBTree.Bnode(RBTree.Rnode(Empty, "f", Empty), "g", RBTree.Rnode(Empty, "h", Empty))), "f"),
      Ok(true));
     (Some("value not present"),
      (RBTree.Bnode(RBTree.Bnode(ra, "b", rc), "d", RBTree.Bnode(re, "f", rg)), "h"),
      Ok(false));
     (Some("empty tree"),
      (Empty, "a"),
      Ok(false));
     (Some("leaf find"),
      (RBTree.Bnode(RBTree.Bnode(ra, "b", rc), "d", RBTree.Bnode(re, "f", rg)), "g"),
      Ok(true));
     (Some("value present"),
      (RBTree.Bnode(RBTree.Bnode(RBTree.Empty, "a", RBTree.Empty), "b", RBTree.Bnode(RBTree.Empty, "c", RBTree.Empty)), "c"),
      Ok(true));

   ])

let rbt_balance_tester t =
  (* Note: RBTree.balance does not always return a balanced tree!  We
     only enforce balance when we reach the black grandparent in a
     red-red invariant violation. *)
  match t with
    RBTree.Empty -> raise InvalidRBTreeError (* we don't ever balance empty trees *)
  | RBTree.Rnode(l,v,r) | RBTree.Bnode(l,v,r)
    -> RBTree.balance (RBTree.color t) l v r

let rbt_balance_int_tests =
  ("rbt_balance_int",
   rbt_balance_tester,
   (=), (=),
   Some(str_int_rbtree, str_int_rbtree),
   [
     (Some("Case A"),
      RBTree.Bnode(RBTree.Rnode(r1,2,RBTree.Empty),
            3,
            RBTree.Empty),
      Ok(RBTree.Rnode(b1,2,b3)));
     (* TODO *)


   ])

let rbt_balance_str_tests =
  ("rbt_balance_str",
   rbt_balance_tester,
   (=), (=),
   Some(str_str_rbtree, str_str_rbtree),
   [
     (Some("Case A"),
      RBTree.Bnode(RBTree.Rnode(ra,"b",RBTree.Empty),
            "c",
            RBTree.Empty),
      Ok(RBTree.Rnode(ba,"b",bc)))
       (* TODO *)
   ])

let rbt_insert_tester f =
  fun (t,x) ->
  check_rbtree f
    (RBTree.insert f
       (check_rbtree f t)
       x)

let int_rbt_insert_tester = rbt_insert_tester int_cmp
let int_rbt_insert_tests_eq = eq_rbtree int_cmp
let rbt_insert_int_tests =
  ("rbt_insert_int",
   int_rbt_insert_tester,
   int_rbt_insert_tests_eq,  (=),
   Some(int_tree_arg_printer,
        str_int_rbtree),
   [
     (Some("simple tree"),
      (RBTree.Bnode(r1, 2, RBTree.Empty), 3),
      Ok(RBTree.Bnode(r1, 2, r3)));
     (* TODO *)
   ])

let str_rbt_insert_tester = rbt_insert_tester str_cmp
let str_rbt_insert_tests_eq = eq_rbtree str_cmp
let rbt_insert_str_tests =
  ("rbt_insert_str",
   str_rbt_insert_tester,
   str_rbt_insert_tests_eq,  (=),
   Some(str_tree_arg_printer,
        str_str_rbtree),
   [
     (Some("simple tree"),
      (RBTree.Bnode(ra, "b", RBTree.Empty), "c"),
      Ok(RBTree.Bnode(ra, "b", rc)));
     (* TODO *)
   ])


let map_printer =
  Some((fun (f,t) -> str_int_rbtree t),
       str_int_list)


let identity x = x

let rbt_map_inorder_tests =
  ("rbt_map_inorder",
   (fun (f,t) -> RBTree.map_inorder f t),
   (=), (=),
   map_printer,
   [
     (Some("simple tree"),
      (identity,RBTree.Bnode(r1, 2, r3)),
      Ok([1; 2; 3]));
     (Some("empty tree"),
      (identity, RBTree.Empty),
      Ok([]));
     (Some("larger tree"),
      ((fun x -> x * x), RBTree.Bnode(RBTree.Bnode(r1, 2, r3), 4, RBTree.Bnode(r5, 6, r7))),
      Ok([1; 4; 9; 16; 25; 36; 49]));
     (Some("tree with duplicates"),
      ((fun x -> x * x), RBTree.Bnode(r2, 2, r2)),
      Ok([4; 4; 4]));
     (Some("unbalanced tree"),
      ((fun x -> x), RBTree.Bnode(RBTree.Bnode(Empty, 1, Empty), 2, Empty)),
      Ok([1; 2]));
     (Some("random values in tree"),
      ((fun x -> x + 10), RBTree.Bnode(RBTree.Bnode(r1, 12, r3), 14, RBTree.Bnode(r5, 16, r7))),
      Ok([11; 22; 13; 24; 15; 26; 17]));
  ])

let rbt_map_revorder_tests =
  ("rbt_map_inorder",
   (fun (f,t) -> RBTree.map_revorder f t),
   (=), (=),
   map_printer,
   [
     (Some("simple tree"),
      (identity,RBTree.Bnode(r1, 2, r3)),
      Ok([3; 2; 1]));
     (Some("empty tree"),
      (identity, RBTree.Empty),
      Ok([]));
     (Some("larger tree"),
      ((fun x -> x * x), RBTree.Bnode(RBTree.Bnode(r1, 2, r3), 4, RBTree.Bnode(r5, 6, r7))),
      Ok([49; 36; 25; 16; 9; 4; 1]));
     (Some("tree with duplicates"),
      ((fun x -> x * x), RBTree.Bnode(r2, 2, r2)),
      Ok([4; 4; 4]));
     (Some("unbalanced tree"),
      ((fun x -> x), RBTree.Bnode(RBTree.Bnode(Empty, 1, Empty), 2, Empty)),
      Ok([2; 1]));
     (Some("random values in tree"),
      ((fun x -> x + 10), RBTree.Bnode(RBTree.Bnode(r1, 12, r3), 14, RBTree.Bnode(r5, 16, r7))),
      Ok([17; 26; 15; 24; 13; 22; 11]));
  ])

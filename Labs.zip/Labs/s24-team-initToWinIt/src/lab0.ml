(* Define a function for the main entry point *)
let main () =
  print_string "Hello, world!\n"
;;

(* Adding a comment here so that I can make a commit with my updated configured email *)
(* Call main *)
main ()

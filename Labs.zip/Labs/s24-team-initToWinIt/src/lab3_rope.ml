open Util (* see util.ml *)

(*******************)
(* PART III: Ropes *)
(*******************)

module Rope = struct
  type rope =
    | Empty
    | Str of string (* leaf node: a string *)
    | Cat of int*int*rope*rope (* inner node: height, length, left, right *)

  let length (r : rope) : int =
    match r with
    | Empty -> 0
    | Str(s) -> String.length s
    | Cat(_,n,_,_)  -> n

  let rec height (r : rope) : int =
    match r with
    | Empty -> 0
    | Str(_) -> 1
    | Cat(h,_,_,_) -> h

  let to_string (r : rope) : string =
    let rec f buf i r =
      match r with
      | Empty -> i
      | Str(s) -> let n = String.length s
                  in (Bytes.blit_string s 0 buf i n; i+n)
      | Cat(_,n,l,r) -> f buf (f buf i l) r
    in
    match r with
    | Empty -> ""
    | Str(s) -> s
    | Cat(_,n,_,_) ->
       let buf = Bytes.create n in
       let _ = f buf 0 r in
       Bytes.to_string buf

  let from_string (s : string) : rope =
    if String.length s = 0
    then Empty
    else Str(s)

  (* Raise an exception for out of bounds access *)
  let out_of_bounds _ = invalid_arg "index out of bounds"

  (* Return the character at index i in r *)
  let rec get (r : rope) (i:int) : char =
    match r with
    | Empty -> out_of_bounds r
    | Str(s) -> String.get s i
    | Cat(_,_,l,r) ->
      let left_len = length l in
      (* determine if i is in left or right child rope *)
      if i < left_len then get l i
      else get r (i - left_len)

  (* Test if the balance invariant does not hold because l is "too big" *)
  let toobig (hl : int) (hr : int) : bool = hl > 2*hr

  (* Test if x is balanced. Does not test if children are balanced. *)
  let is_balanced (x : rope) : bool =
    match x with
    | Empty | Str _ -> true
    | Cat(_,_,l,r) ->
       let hl,hr = height l, height r in
       not (toobig hl hr || toobig hr hl)

  (* Test if x is balanced and all decendants are balanced. *)
  let rec is_rec_balanced (x : rope) : bool =
    match x with
    | Empty | Str _ -> true
    | Cat(_,_,l,r) ->
       is_rec_balanced l && is_rec_balanced r && is_balanced x

  (* Create a new rope with left child l and right child r.  Both l
     and r must be balanced and the invariant must hold without any
     rebalancing of l and/or r.  That is:
     (height l <= 2 * height r) && (height r <= height l)
   *)
  let create (l : rope) (r : rope) : rope =
    match l,r with
    | Empty,_ -> r
    | _,Empty -> l
    | _ ->
       let hl,hr = height l,height r in
       if toobig hl hr then invalid_arg "Rope.create: left too big"
       else if toobig hr hl then invalid_arg "Rope.create: right too big"
       else let x = Cat(1+max hl hr, length l + length r, l, r) in
            if is_balanced x then x
            else invalid_arg "Rope.create: unbalanced result"

  (* Right rotation *)
  let rot_right(l : rope) (r : rope) : rope =
    match l with
    | Empty | Str _ -> invalid_arg "Rope.rot_right: invalid arguments" (* left needs to be a rope with at least two children *)
    | Cat(_, _, ll, lr) ->
      create ll (create lr r)

  (* Left rotation *)
  (* NOTE: I moved this to before rot_right_left so that it could be used there, since it was out of scope *)
  let rot_left (l : rope) (r : rope) : rope =
    match r with
    | Empty | Str _ -> invalid_arg "Rope.rot_left: invalid arguments" (* right needs to be a rope with at least two children *)
    | Cat(_, _, rl, rr) ->
      create (create l rl) rr

  (* Right rotation, then left rotation *)
  let rot_right_left (l : rope) (r : rope) : rope =
    match l with
    | Empty | Str _ -> invalid_arg "Rope.rot_right_left: invalid arguments" (* left needs to be a rope with two children *)
    | Cat(_, _, ll, lr) ->
      (* do a right rotation on lr, then a left rotation on the whole thing *)
      match lr with
      | Empty | Str _ -> invalid_arg "Rope.rot_right_left: invalid arguments"
      | Cat(_, _, lrl, lrr) ->
        create (create ll lrl) (create lrr r)

  (* Left rotation, then right rotation *)
  let rot_left_right (l : rope) (r : rope) : rope =
    match r with
    | Empty | Str _ -> invalid_arg "Rope.rot_left_right: invalid arguments"  (* left needs to be a rope with two children *)
    | Cat(_, _, rl, rr) ->
      (* do a left rotation on rl, then a right rotation on the whole thing *)
      match rl with
      | Empty | Str _ -> invalid_arg "Rope.rot_left_right: invalid arguments"
      | Cat(_, _, rll, rlr) ->
        create (create l rll) (create rlr rr)

  (* Same as create but performs one step of rebalancing if
     necessary. Assumes l and r are balanced and
     (height l - 1 <= 2 * height r) && (height r - 1 <= 2 * height l)
   *)
  let bal (l : rope) (r : rope) : rope =
    match l, r with
    | Empty, _ -> r
    | _, Empty -> l
    | _ ->
      (* do one rotation at most *)
       let hl, hr = height l, height r in
       if hl > hr + 1 then rot_right l r
       else if hr > hl + 1 then rot_left l r
       else create l r

  (* Same as create and bal, but no assumptions are made on the
     relative heights of l and r. *)
  let rec cat (l : rope) (r : rope) : rope =
    match l, r with
    | Empty, _ -> r 
    | _, Empty -> l
    | _ ->
      let hl, hr = height l, height r in
      if hl > hr + 1 then
        if height l > 1 then
          if height (bal l r) > 1 then bal l r
          else bal (rot_right l r) r
        else bal (rot_right l r) r
      else if hr > hl + 1 then
        if height r > 1 then
          if height (bal l r) > 1 then bal l r
          else bal l (rot_left l r)
        else bal l (rot_left l r)
      else create l r

  (* Extract the subrope beginning at position pos and containing len
     number of characters *)
  let rec sub (r : rope) (pos:int) (len:int) : rope =
    match r with
    | Empty -> if pos = 0 && len = 0 then Empty
               else out_of_bounds r
    | Str(s) ->
       if pos + len > String.length s
       then out_of_bounds r
       else from_string(String.sub s pos len)
    | Cat(_,_,l,r) ->
       let left_len = length l in
       if pos + len <= left_len then sub l pos len
       else if pos >= left_len then sub r (pos - left_len) len
       else cat (sub l pos (left_len - pos)) (sub r 0 (pos + len - left_len))

end

;;

(*********)
(* Tests *)
(*********)

let rope_repeat s i =
  let rec h i r =
    if i <= 0 then r
    else h (i-1) (Rope.cat r s)
  in h i Empty
;;


let rope_pair_printers = Some(str_pair Rope.to_string  Rope.to_string, Rope.to_string)

(* validate heights and lengths of test arguments *)
let rope_check_arg r =
  let rec f r =
    match r with
    | Rope.Empty | Rope.Str _ -> true
    | Rope.Cat(h,n,l,r) ->
       f l && f r
       && n = Rope.length l + Rope.length r
       && h = 1 + max (Rope.height l) (Rope.height r)
  in if f r then r
     else invalid_arg "test arg check"

let rope_pair_helper f : (Rope.rope*Rope.rope)->Rope.rope =
  (fun (l,r) -> f (rope_check_arg l) (rope_check_arg r))

(* Basic Tests (do not modify) *)

let to_string_tests =
  ("Rope.to_string",
   Rope.to_string, (=), (=),
   Some(Rope.to_string, str_str),
   [
     (None, Rope.Empty, Ok "");
     (None, Rope.Str "foo" , Ok "foo");
     (None, Rope.Cat(2,6,
                     Rope.Str "foo",
                     Rope.Str "bar"),
      Ok "foobar");
   ]
  )

let length_tests =
  ("Rope.length",
   Rope.length, (=), (=),
   Some(Rope.to_string, string_of_int),
   [
     (None, Rope.Empty, Ok 0);
     (None, Rope.Str "foo", Ok 3);
     (None, Rope.Cat(2,6,
                     Rope.Str "foo",
                     Rope.Str "bar"),
      Ok 6);
   ]
  )

let height_tests =
  ("Rope.height",
   Rope.height, (=), (=),
   Some(Rope.to_string, string_of_int),
   [
     (None, Rope.Empty, Ok 0);
     (None, Rope.Str "foo", Ok 1);
     (None, Rope.Cat(2,6,
                     Rope.Str "foo",
                     Rope.Str "bar"),
      Ok 2);
   ]
  )

(* Rotations *)
let rot_right_helper = rope_pair_helper Rope.rot_right
let rot_right_tests =
  ("Rope.rot_right",
   rot_right_helper,
   (=), (=),
   rope_pair_printers,
   [
     (None,
      (Rope.Cat(2,4, Rope.Str "ll", Rope.Str "lr"),
       Rope.Str "r"),
      Ok (Rope.Cat(3,5,
                   Rope.Str "ll",
                   Rope.Cat(2,3,Rope.Str "lr", Rope.Str "r")))
     );

     (None,
     (Rope.Cat(3,11, Rope.Cat(2,8, Rope.Str "start", Rope.Str "mid"), Rope.Str "end"),
      Rope.Str "append"),
     Ok (Rope.Cat(3,17,
                  Rope.Cat(2,8, Rope.Str "start", Rope.Str "mid"),
                  Rope.Cat(2,9, Rope.Str "end", Rope.Str "append")))
     );

     (* some of these test sentences are nonsensical in word 'order' and thats okay. no one is perfect *)
     (None,
     (Rope.Cat(4,14, Rope.Cat(3,10, Rope.Cat(2,7, Rope.Str "the", Rope.Str "lazy"), Rope.Str "dog"), Rope.Str "over"),
      Rope.Str "the"),
     Ok (Rope.Cat(4,17,
                  Rope.Cat(3,10, Rope.Cat(2,7, Rope.Str "the", Rope.Str "lazy"), Rope.Str "dog"),
                  Rope.Cat(2,7, Rope.Str "over", Rope.Str "the")))
     );

     (None,
     (Rope.Cat(2, 52, Rope.Str "abcdefghijklmnopqrstuvwxyz", Rope.Str "abcdefghijklmnopqrstuvwxyz"),
     Rope.Str "abcdefghijklmnopqrstuvwxyz"),
      Ok (Rope.Cat(3,78,
                   Rope.Str "abcdefghijklmnopqrstuvwxyz",
                   Rope.Cat(2, 52, Rope.Str "abcdefghijklmnopqrstuvwxyz", Rope.Str "abcdefghijklmnopqrstuvwxyz")))
     );

     (None,
     (Rope.Cat(3,31, Rope.Cat(2,28, Rope.Str "ilovewritingtests", Rope.Str "theyresofun"), Rope.Str "yay"),
      Rope.Str ""),
     Ok (Rope.Cat(3,31,
                  Rope.Cat(2,28, Rope.Str "ilovewritingtests", Rope.Str "theyresofun"),
                  Rope.Cat(2,3, Rope.Str "yay", Rope.Str "")))
     );

     (None,
      (Rope.Cat(2,0, Rope.Str "", Rope.Str ""),
       Rope.Str ""),
      Ok (Rope.Cat(3,0,
                   Rope.Str "",
                   Rope.Cat(2,0,Rope.Str "", Rope.Str "")))
     );

   ]
  )


let rot_right_left_helper = rope_pair_helper Rope.rot_right_left
let rot_right_left_tests =
  ("Rope.rot_right_left",
   rot_right_left_helper,
   (=), (=),
   rope_pair_printers,
   [
     (None,
      (Rope.Cat(3,8,
                Rope.Str "ll",
                Rope.Cat(2,6,
                          Rope.Str"lrl",
                          Rope.Str"lrr")),
       Rope.Str "r"),
      Ok (Rope.Cat(3,9,
                   Rope.Cat(2,5, Rope.Str "ll", Rope.Str "lrl"),
                   Rope.Cat(2,4,Rope.Str "lrr", Rope.Str "r")))
     );

    ]
   )


let rot_left_helper = rope_pair_helper Rope.rot_left
let rot_left_tests =
  ("Rope.rot_left",
   rot_left_helper,
   (=), (=),
   rope_pair_printers,
   [
     (None,
      (Rope.Str "l",
       Rope.Cat(2,4, Rope.Str "rl", Rope.Str "rr")),
      Ok (Rope.Cat(3,5,
                   Rope.Cat(2,3,Rope.Str "l", Rope.Str "rl"),
                   Rope.Str "rr"))
     );
     
     (None,
     (Rope.Str "prepend",
      Rope.Cat(3,11, Rope.Str "start", Rope.Cat(2,6, Rope.Str "mid", Rope.Str "end"))),
     Ok (Rope.Cat(3,18,
                  Rope.Cat(2,12, Rope.Str "prepend", Rope.Str "start"),
                  Rope.Cat(2,6, Rope.Str "mid", Rope.Str "end")))
    );
    
    (None,
    (Rope.Str "the",
      Rope.Cat(4,14, Rope.Str "over", Rope.Cat(3,10, Rope.Cat(2,7, Rope.Str "the", Rope.Str "lazy"), Rope.Str "dog"))),
    Ok (Rope.Cat(4,17,
                 Rope.Cat(2,7, Rope.Str "the", Rope.Str "over"),
                 Rope.Cat(3,10, Rope.Cat(2,7, Rope.Str "the", Rope.Str "lazy"), Rope.Str "dog")))
    );

    (None,
    (Rope.Str "abcdefghijklmnopqrstuvwxyz",
      Rope.Cat(2, 52, Rope.Str "abcdefghijklmnopqrstuvwxyz", Rope.Str "abcdefghijklmnopqrstuvwxyz")),

     Ok (Rope.Cat(3,78,
                  Rope.Cat(2, 52, Rope.Str "abcdefghijklmnopqrstuvwxyz", Rope.Str "abcdefghijklmnopqrstuvwxyz"),
                  Rope.Str "abcdefghijklmnopqrstuvwxyz"))
    );

    (None,
    (Rope.Str "",
      Rope.Cat(3,31, Rope.Str "yay", Rope.Cat(2,28, Rope.Str "ilovewritingtests", Rope.Str "theyresofun"))),
    Ok (Rope.Cat(3,31,
                 Rope.Cat(2,3, Rope.Str "", Rope.Str "yay"),
                 Rope.Cat(2,28, Rope.Str "ilovewritingtests", Rope.Str "theyresofun")))
    );

    (None,
     (Rope.Str "",
      Rope.Cat(2,0, Rope.Str "", Rope.Str "")),
     Ok (Rope.Cat(3,0,
                  Rope.Cat(2,0,Rope.Str "", Rope.Str ""),
                  Rope.Str ""))
    );

   ]
  )

let rot_left_right_helper = rope_pair_helper Rope.rot_left_right
let rot_left_right_tests =
  ("Rope.rot_left_right",
   rot_left_right_helper,
   (=), (=),
   rope_pair_printers,
   [
     (None,
      (Rope.Str "l",
       Rope.Cat(3,8,
                Rope.Cat(2,6,
                         Rope.Str "rll",
                         Rope.Str "rlr"),
                Rope.Str "rr")),
      Ok (Rope.Cat(3,9,
                   Rope.Cat(2,4, Rope.Str "l", Rope.Str "rll"),
                   Rope.Cat(2,5,Rope.Str "rlr", Rope.Str "rr")))
     );
    
   ]
  )

(* create *)
let create_helper = rope_pair_helper Rope.create
let create_ok_list = [
    (None,
     (Rope.Empty, Rope.Empty),
     Ok (Rope.Empty));
    (None,
     (Rope.Empty, Rope.Str "x"),
     Ok (Rope.Str "x"));
    (None,
     (Rope.Str "x", Rope.Empty),
     Ok (Rope.Str "x"));
    (None,
     (Rope.Str "x", Rope.Str "y"),
     Ok (Rope.Cat(2, 2, Rope.Str "x", Rope.Str "y")));
  ]
let create_all_list =
  create_ok_list
  @ [
      (None,
       (Rope.Cat(3,3,
                 Rope.Cat(2,2,Rope.Str "x", Rope.Str "y"),
                 Rope.Str "z"),
        Rope.Str "w"),
       Error (Invalid_argument "Rope.create: left too big"));
      (None,
       (Rope.Str "w",
        Rope.Cat(3,3,
                 Rope.Cat(2,2,Rope.Str "x", Rope.Str "y"),
                 Rope.Str "z")),
       Error (Invalid_argument "Rope.create: right too big"));
    ]
let create_tests =
  ("Rope.create",
   create_helper,
   (=), (=),
   rope_pair_printers,
   create_all_list
  )

(* balance *)
let bal_helper = rope_pair_helper Rope.bal
let bal_ok_list =
  create_ok_list (* handle everything Rope.create does *)
  @ [
    (None,
    (Rope.Empty, Rope.Empty),
    Ok (Rope.Empty));
   (None,
    (Rope.Empty, Rope.Str "x"),
    Ok (Rope.Str "x"));
   (None,
    (Rope.Str "x", Rope.Empty),
    Ok (Rope.Str "x"));
   (None,
    (Rope.Str "x", Rope.Str "y"),
    Ok (Rope.Cat(2, 2, Rope.Str "x", Rope.Str "y")));
    ]
let bal_all_list =
  bal_ok_list
  @ [
    (None,
    (Rope.Str "left", Rope.Str "right"),
    Ok (Rope.Cat(2, 9, Rope.Str "left", Rope.Str "right")));

    (None,
    (Rope.Str "abc", Rope.Str "def"),
    Ok (Rope.Cat(2, 6, Rope.Str "abc", Rope.Str "def")));

    (None,
    (Rope.Str "hello", Rope.Str "world"),
    Ok (Rope.Cat(2, 10, Rope.Str "hello", Rope.Str "world")));

    (None,
    (Rope.Str "goodbye", Rope.Str "cruel"),
    Ok (Rope.Cat(2, 12, Rope.Str "goodbye", Rope.Str "cruel")));

    (None,
    (Rope.Str "orange", Rope.Str "apple"),
    Ok (Rope.Cat(2, 11, Rope.Str "orange", Rope.Str "apple")));

    (None,
    (Rope.Str "this", Rope.Str "sucks"),
    Ok (Rope.Cat(2, 9, Rope.Str "this", Rope.Str "sucks")));
    ]
let bal_tests =
  ("Rope.bal",
   bal_helper,
   (=), (=),
   rope_pair_printers,
   bal_all_list
  )

(* cat *)
let cat_helper = rope_pair_helper Rope.cat
let cat_list =
  bal_ok_list (* handle everything Rope.bal does *)
  @ [ 
      (None,
       (Rope.Str "abc", Rope.Str "def"),
       Ok (Rope.Cat(2, 6, Rope.Str "abc", Rope.Str "def")));

      (None,
       (Rope.Str "hello", Rope.Str "world"),
       Ok (Rope.Cat(2, 10, Rope.Str "hello", Rope.Str "world")));

      (None,
       (Rope.Str "goodbye", Rope.Str "cruel"),
       Ok (Rope.Cat(2, 12, Rope.Str "goodbye", Rope.Str "cruel")));

      (None,
       (Rope.Str "orange", Rope.Str "apple"),
       Ok (Rope.Cat(2, 11, Rope.Str "orange", Rope.Str "apple")));

      (None,
       (Rope.Str "this", Rope.Str "sucks"),
       Ok (Rope.Cat(2, 9, Rope.Str "this", Rope.Str "sucks")));
    ]

let cat_tests =
  ("Rope.cat",
   cat_helper,
   (=), (=),
   rope_pair_printers,
   cat_list
  )

(* get *)
let get_helper (r,i) = Rope.get r i
let get_printer =
  Some(str_pair Rope.to_string  string_of_int, (fun c -> Printf.sprintf "%c" c))
let get_tests =
  ("Rope.get",
   get_helper, (=), (=),
   get_printer,
   [
     (None, (Rope.Str "foo", 0), Ok 'f');
     (None, (Rope.Str "foo", 1), Ok 'o');
     (None, (Rope.Cat(2,6, Rope.Str "hello", Rope.Str "world"), 5), Ok 'w');
     (None, 
     (Rope.Cat(3,13, 
               Rope.Cat(2,10, Rope.Str "deep", Rope.Cat(1,6, Rope.Str "er", Rope.Str "nest")), 
               Rope.Str "ing"), 
      7), 
     Ok 'e');
     (None, 
     (Rope.Cat(3,11, 
               Rope.Cat(2,8, Rope.Str "start", Rope.Str "mid"), 
               Rope.Str "end"), 
      11), 
      Error(Invalid_argument("index out of bounds")));
      (None, 
      (Rope.Cat(3,8, 
                Rope.Cat(2,5, Rope.Str "start", Empty), 
                Rope.Str "end"), 
       4), 
      Ok 't')
     
   ]
  )

(* sub *)
let sub_helper (r,pos,len) = Rope.sub r pos len
let sub_printer =
  Some((fun(r,pos,len) ->
      "(" ^ (Rope.to_string r) ^  ","
      ^ (string_of_int pos) ^ ","
      ^ (string_of_int len) ^ ")"),
       Rope.to_string)
let sub_tests =
  ("Rope.sub",
   sub_helper, (=), (=),
   sub_printer,
   [
     (None, (Rope.Str "foo", 1, 2),
      Ok (Rope.Str "oo"));
    (None,
      (Rope.Cat(2,10, Rope.Str "Hello", Rope.Str "World"), 3, 5),
      Ok (Rope.Cat(2,5, Rope.Str "lo", Rope.Str "Wor")));
    (None,
      (Rope.Cat(3,19, Rope.Cat(2,10, Rope.Str "Nested", Rope.Str "Rope"), Rope.Str "Structure"), 0, 6),
      Ok (Rope.Str "Nested"));
    (None,
      (Rope.Cat(3,13, Rope.Cat(2,9, Rope.Str "Sub", Rope.Str "string"), Rope.Str "Test"), 3, 8),
      Ok (Rope.Cat(2,8, Rope.Str "string", Rope.Str "Te")));
    (None,
      (Rope.Cat(2,3, Rope.Str "a", Rope.Cat(1,2, Rope.Str "b", Rope.Str "c")), 1, 2),
      Ok (Rope.Cat(2,2, Rope.Str "b", Rope.Str "c")));
    (None,
      (Rope.Cat(3,10, Rope.Cat(2,5, Rope.Str "Empty", Empty), Rope.Str "Nodes"), 4, 4),
      Ok (Rope.Cat(2,4, Rope.Str "y", Rope.Str "Nod")));
   ]
  )

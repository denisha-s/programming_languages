open Util (* see util.ml *)

(******************)
(** Starter Code **)
(******************)

(*** Implementing higher-order functions ***)

let rec map (f : 'a->'b) (l : 'a list) : 'b list =
  match l with
  | [] -> []
  | hd::tl -> (f hd) :: (map f tl) (* cons f applied to head with map(f, tl) *)

let rec filter (f : 'a->bool) (l : 'a list) : 'a list =
  match l with
  | [] -> []
  | hd::tl ->
      if f hd then
        hd :: (filter f tl) (* if f(hd) true, then cons hd to list *)
      else
        filter f tl (* don't cons hd, recursively move on with tl *)

let rec fold_left (f: 'y ->'x->'y) (y:'y) (l:'x list) : 'y =
  match l with
  | [] -> y
  | hd::tl -> fold_left f (f y hd) tl (* change accumulator y to be f with current element *)

let rec fold_right (f : 'x->'y->'y) (y:'y) (l:'x list) : 'y =
  match l with
  | [] -> y
  | hd::tl -> f hd (fold_right f y tl) (* apply f to head, recursively fold tl from right to left *)


(*** Using higher-order functions ***)


(* Concatenate two lists. *)
let append (l1 : 'a list) (l2 : 'a list) : 'a list =
  fold_right (fun x y -> x :: y) l2 l1 (* cons right elements of l1 to l2 one by one *)

(* rev_append l1 l2 reverses l1 and concatenates it with l2 *)
let rev_append (l1 : 'a list) (l2 : 'a list) : 'a list =
  fold_left (fun x y -> y::x) l2 l1

(* Concatenate a list of lists. *)
let flatten (l : 'a list list) : 'a list =
  fold_right append [] l


(* Insertion Sort *)

(* Insert elt into sorted list l in sorted order *)
let rec insert (cmp : 'a->'a->bool) (elt :'a) (l:'a list) : 'a list =
  match l with
    |[] -> [elt]
    |h::t -> 
      (if cmp elt h
        then elt::h::t
        else h::(insert cmp elt t))

let insertionsort (cmp : 'a->'a->bool) (l:'a list) : 'a list =
  fold_left (fun x y -> insert cmp y x) [] l


(* Selection Sort *)

(* Select the initial element from l based on cmp.  Return a tuple of
   the initial element and the list with the initial element
   removed. *)
let select (cmp : 'a->'a->bool) (l:'a list) : 'a * 'a list =
  match l with
  | [] -> invalid_arg "select"
  | a::d ->
     let ie  = (fold_left (fun x y -> if cmp x y then x else y) a d) in
     let rec filterinit lst = 
      match lst with
      | [] -> []
      | h::t -> if h = ie then t else h::(filterinit t)
     in (ie, filterinit l)

let rec selectionsort (cmp : 'a->'a->bool) (l:'a list) : 'a list =
  match l with
  | [] -> []
  | a::d -> 
      let (ie, newlist) = select cmp l in ie::selectionsort cmp newlist


(* Quicksort *)

(* Partion list l around elt.  Return a tuple consisting of all
   elements before elt and all elements after elt. *)
let pivot (cmp : 'a->'a->bool) (elt :'a) (l:'a list) : 'a list * 'a list =
  let fold_fn x (before, after) =
    if cmp x elt then (x::before, after)
    else (before, x::after)
  in fold_right fold_fn ([], []) l 

(* The simple implementation of quicksort recurses on the two sublists
   and appends the sorted results. *)
let rec quicksort_simple (cmp : 'a->'a->bool) (l : 'a list) : 'a list =
  match l with
  | [] -> []
  | hd::tl ->
      (* use let binding to make life easier *)
      let before, after = pivot cmp hd tl in
      let sorted_before = quicksort_simple cmp before in (* sort before pivot list *)
      let sorted_after = quicksort_simple cmp after in (* sort after pivot list *)
      append (append sorted_before [hd]) sorted_after (* append to make big sorted list *)

(* The better implementation of quicksort  elides the append by passing
   a "tail" list to recursive calls.  Sorted results are directly
   cons'ed onto the tail, avoiding the need for an extra append. *)
let quicksort_better (cmp : 'a->'a->bool) (l : 'a list) : 'a list =
  let rec f (cmp : 'a->'a->bool) (l : 'a list) (r : 'a list) : 'a list =
    match l with
    | [] -> r
    | hd::tl ->
        let before, after = pivot cmp hd tl in
        let sorted_before = f cmp before [] in
        let sorted_after = f cmp after r in
        append sorted_before (append [hd] sorted_after)
  in f cmp l []

(***********)
(** Tests **)
(***********)

(* See description in testing.ml *)

let list_cmp cmp l1 l2 =
  (List.sort cmp l1) = (List.sort cmp l2)

let int_list_cmp l1 l2 =
  list_cmp (-) l1 l2


let map_tests =
  ("map", (fun (f,l)->map f l), (=), (=),
   Some((fun (f,l) -> str_int_list l),
        str_int_list),
   [
     (Some("simple list"), ((fun x -> 1+x), [1;2;3;4;5]), Ok [2;3;4;5;6]);
     (Some("empty list"), ((fun x -> x * 2), []), Ok []);
     (Some("identity function"), ((fun x -> x), [1;2;3]), Ok [1;2;3]);
     (Some("less than 2"), ((fun x -> if x < 2 then 1 else 0), [1;2;3;4]), Ok [1; 0; 0; 0]);
     (Some("square numbers with repeats"), ((fun x -> x * x), [1;1;2;3;4]), Ok [1; 1; 4; 9; 16]);
     (Some("spread negativity"), ((fun x -> -x), [1; 2; 3; 4; 5]), Ok [-1; -2; -3; -4; -5]);
  ])

let filter_tests =
  ("filter", (fun (f,l)->filter f l), (=), (=),
   Some((fun (f,l) -> str_int_list l),
        str_int_list),
   [
     (Some("simple list"), ((fun x -> (x mod 2)=0), [1;2;3;4;5]), Ok [2;4]);
     (Some("even numbers"), ((fun x -> x mod 2 = 0), [10;15;20;25;30]), Ok [10;20;30]);
     (Some("always true"), ((fun _ -> true), [1;2;3;4;5]), Ok [1;2;3;4;5]);
     (Some("always false"), ((fun _ -> false), [1;2;3;4;5]), Ok []);
     (Some("negative numbers"), ((fun x -> x < 0), [-5;0;5;-10;10]), Ok [-5;-10]);
     (Some("greater than 5"), ((fun x -> x > 5), [1;6;2;7;3;8]), Ok [6;7;8]);
  ])

let fold_left_tests =
  ("fold_left", (fun (f,y,l)->fold_left f y l), (=), (=),
   Some((fun (f,y,l) -> str_pair string_of_int str_int_list (y,l)),
        string_of_int),
   [
     (Some("+"), ((+), 0, [1;2;3]), Ok 6);
     (Some("-"), ((-), 0, [1;2;3]), Ok (-6));
     (Some("sum with initial 10"), ((+), 10, [1;2;3;4]), Ok 20);
     (Some("product with initial 1"), (( * ), 1, [1;2;3;4]), Ok 24);
     (Some("min in list"), ((fun acc x -> min acc x), max_int, [10;5;20;0;2]), Ok 0);
     (Some("max in list"), ((fun acc x -> max acc x), min_int, [1;6;3;2]), Ok 6);
     (Some("count positives"), ((fun acc x -> if x > 0 then acc + 1 else acc), 0, [-1;2;3;-4;5]), Ok 3);
  ])

let fold_right_tests =
  ("fold_right", (fun (f,y,l)->fold_right f y l), (=), (=),
   Some((fun (f,y,l) -> str_pair string_of_int str_int_list (y,l)),
        string_of_int),
   [
     (Some("+"), ((+), 0, [1;2;3]), Ok 6);
     (Some("-"), ((-), 0, [1;2;3]), Ok 2);
     (Some("*"), (( * ), 1, [1;2;3]), Ok 6);
     (Some("negative sum"), ((fun x acc -> acc - x), 0, [1;2;3]), Ok (-6));
     (Some("list length"), ((fun x acc -> acc + 1), 0, [1;2;3;4;5]), Ok 5);
     (Some("max in list"), ((fun x acc -> if x > acc then x else acc), min_int, [1;2;3;4;5]), Ok 5);
     (Some("min in list with negative"), ((fun x acc -> if x < acc then x else acc), max_int, [1;-2;3;4;5]), Ok (-2));
  ])


let append_tests =
  ("append", (fun (l1,l2)->append l1 l2), (=), (=),
   Some((fun x -> str_pair str_int_list  str_int_list x),
        str_int_list),
   [
     (Some("simple list"), ([1;2],[3;4]), Ok [1;2;3;4]);
     (Some("empty lists"), ([],[]), Ok []);
     (Some("first list empty"), ([],[1;3;4]), Ok [1;3;4]);
     (Some("second list empty"), ([1;2;3],[]), Ok [1;2;3]);
     (Some("longer unsorted lists"), ([1;3;6;10],[3;7;8;14]), Ok [1;3;6;10;3;7;8;14]);
     (Some("duplicate elements"), ([1;2;3],[3;4;5]), Ok [1;2;3;3;4;5]);
  ])

let rev_append_tests =
  ("rev_append", (fun (l1,l2)->rev_append l1 l2), (=), (=),
   Some((fun x -> str_pair str_int_list  str_int_list x),
        str_int_list),
   [
     (Some("simple list"), ([1;2],[3;4]), Ok [2;1;3;4]);
     (Some("empty lists"), ([],[]), Ok []);
     (Some("first empty"), ([],[1;3;4]), Ok [1;3;4]);
     (Some("second empty"), ([1;2;3],[]), Ok [3;2;1]);
     (Some("longer unsorted"), ([1;3;6;10],[3;7;8;14]), Ok [10;6;3;1;3;7;8;14]);
     (Some("duplicates"), ([2;2;2],[2;2;2]), Ok [2;2;2;2;2;2]);
  ])

let flatten_tests =
  ("flatten", (fun l -> flatten l), (=), (=),
   Some((fun l -> "[" ^ str_x_list (str_int_list) l ";" ^ "]" ),
        str_int_list),
   [
     (Some("simple list"), [[1;2];[3;4]], Ok [1;2;3;4]);
     (Some("simple list 2"), [[3;4]; [1;2]], Ok [3;4;1;2]);
     (Some("single element lists"), [[3]; [1]], Ok [3;1]);
     (Some("empty lists"), [[]; []], Ok []);
     (Some("longer lists"), [[1;2;3;4;5;6;7;8]; [8;7;6;5;4;3;2;1]], Ok [1;2;3;4;5;6;7;8;8;7;6;5;4;3;2;1]);
     (Some("multiple lists"), [[3;4]; [1;2]; [5;6]; [9;1]; [8;8]], Ok [3;4;1;2;5;6;9;1;8;8]);
     (Some("multiple single/empty lists"), [[]; [1]; [2]; []; []; [5]], Ok [1;2;5]);
   ]
  )


let sort_test_cases = [
    (Some("simple list"), ((<),[1;3;4;2;5]), Ok [1;2;3;4;5]);
    (Some("simple greater"), ((>),[5;2;3;4;1]), Ok [5;4;3;2;1]);
    (Some("empty list"), ((>),[]), Ok []);
    (Some("all equal values"), ((>),[5;5;5;5;5]), Ok [5;5;5;5;5]);
    (Some("already sorted"), ((<),[1;2;3;4;5]), Ok [1;2;3;4;5]);
    (Some("large list"), ((<),[12;36;1;98;101;55;54;237;107;102]), Ok [1;12;36;54;55;98;101;102;107;237]);
  ]

let insert_tests =
  ("insert", (fun (cmp,elt,l)->insert cmp elt l), (=), (=),
   Some(((fun (cmp,elt,l) -> str_pair string_of_int str_int_list (elt,l)),
         (fun y -> str_int_list y)
     )),
   [
     (Some("simple <"), ((<), 0, [-1;1;2]), Ok ([-1; 0; 1; 2]));
     (Some("simple >"), ((>), 0, [2;1;-1]), Ok ([2; 1; 0; -1]));
     (Some("duplicated >"), ((>), -1, [2;1;0;-1]), Ok ([2; 1; 0; -1; -1]));
     (Some("duplicated <"), ((<), -1, [-1;0;1;2]), Ok ([-1;-1;0;1;2]));
     (Some("all neg 0 >"), ((>), 0, [-2;-1;-1]), Ok ([0;-2; -1;-1]));
     (Some("all neg 0 <"), ((<), 0, [-1;-1;-4]), Ok ([-1;-1;-4;0]));
     (Some("all pos >"), ((>), -3, [3;2;1]), Ok ([3;2;1;-3]));
     (Some("all pos <"), ((<), 3, [1;7;8]), Ok ([1;3;7;8]));
   ])

let insertionsort_tests =
  ("insertionsort", (fun (cmp,l) -> insertionsort cmp l), (=), (=),
   Some((fun (cmp,l) -> str_int_list l),
        str_int_list),
   sort_test_cases)


let select_test_eq (s1,l1) (s2,l2) =
  (s1 = s2) && (int_list_cmp l1 l2)

let select_tests =
  ("select", (fun (cmp,l)->select cmp l), select_test_eq, (=),
   Some(((fun (cmp,l) -> str_int_list l),
         (fun (s,l) -> str_pair string_of_int str_int_list (s,l))
     )),
   [
     (Some("simple <"), ((<), [1;-1;2]), Ok (-1,[2;1]));
     (Some("simple >"), ((>), [1;-1;2]), Ok (2,[1;-1]));
     (Some("long <"), ((<), [9;3;5;4;8;7;2]), Ok (2,[9;3;5;4;8;7]));
     (Some("long >"), ((>), [1;3;5;4;8;7;2]), Ok (8,[1;3;5;4;7;2]));
     (Some("multiple <"), ((<), [1;1;2;3;4;5;]), Ok (1,[1;2;3;4;5;]));
     (Some("multiple >"), ((>), [1;1;2;3;5;5;]), Ok (5,[1;1;2;3;5;]));
     (Some("simple ="), ((=), [-5;-3;-8;-1;-4]), Ok (-4,[-5; -3; -8; -1]));
   ])


let selectionsort_tests =
  ("selectionsort", (fun (cmp,l) -> selectionsort cmp l), (=), (=),
   Some((fun (cmp,l) -> str_int_list l),
        str_int_list),
   sort_test_cases)


let pivot_test_eq (a1,b1) (a2,b2) =
  (int_list_cmp a1 a2) && (int_list_cmp b1 b2)

let pivot_tests =
  ("pivot", (fun (cmp,elt,l)->pivot cmp elt l), pivot_test_eq, (=),
   Some(((fun (cmp,elt,l) -> str_pair string_of_int str_int_list (elt,l)),
         (fun y -> str_pair str_int_list  str_int_list y)
     )),
   [
     (Some("simple <"), ((<), 0, [-1;1;0;-2; 2]), Ok ([-2; -1],[2; 0; 1]));
     (Some("simple >"), ((>), 0, [-1;1;0;-2; 2]), Ok ([2; 1], [-2; 0; -1]));
     (Some("empty list"), ((<), 0, []), Ok ([], []));
     (Some("single-element list"), ((<), 0, [5]), Ok ([], [5]));
     (Some("all elements smaller"), ((<), 5, [1;2;3;4]), Ok ([1;2;3;4], []));
     (Some("all elements greater"), ((>), 5, [10;20;30]), Ok ([10;20;30], []));
     (Some("multiple occurrences"), ((=), 5, [5;2;5;8;5]), Ok ([5;5;5], [2;8]));
  ])

let quicksort_simple_tests =
  ("quicksort_simple", (fun (cmp,l) -> quicksort_simple cmp l), (=), (=),
   Some((fun (cmp,l) -> str_int_list l),
        str_int_list),
   sort_test_cases)

let quicksort_better_tests =
  ("quicksort_better", (fun (cmp,l) -> quicksort_better cmp l), (=), (=),
   Some((fun (cmp,l) -> str_int_list l),
        str_int_list),
   sort_test_cases)
